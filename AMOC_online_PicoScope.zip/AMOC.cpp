﻿// PALS.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "AMOC_tool.h"
#include <cmath>
#include <numeric>
#include<algorithm>
#include <iomanip>
#include <cstdlib>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "ps5000aApi.h"
#include <iostream>
#include <stdio.h>
#include "pico_setting.h"
#include "Get_parameters.h"
#include <thread>
#include <Windows.h>
#include <ctime>
using namespace std;

//测试阶段基本参数设置区
#define judgeway   1
//把judgeway定义为2(经过shape),定义为1(经过fiexd) 或者0(过阈收谱,若为两道以上TAC，则程序识别的有效脉冲为0)
#define save_style  1// 1:amplitude or  0:pulse
//#define measurement_model//测量模式:AMOC：1 OR HPGE：2 
const int leftcount = 100, rightcount = 50;//shape filter的左长度与右长度
const int pulse_wide = leftcount + rightcount;
double lower0[pulse_wide], upper0[pulse_wide];
int a1_clock, c1_clock, a2_clock, c2_clock;
int st;
int num_0;
int ks = 0;
extern int WCOUNTS = 200;
extern int N_Epre = 2000;
extern int N_Etotal = 6000;

void getdata_thread_D(pico_ctrl* p1, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2) {
	while (st == 0)
	{
		if (a1_clock == 0) {

			//clock_t t_start, t_stop;
			//t_start = clock();
			p1->get_rapidBuffer(PS5000A_CHANNEL_D, rapidBuffers_D1);

			//t_stop = clock();
			//double t01 = (t_stop - t_start);
			//cout << "\n" << "collect time1 : " << t01 / 1000 << " s" << endl;
			/*for (int i = 0; i != 510; i++)
			{
				cout << "rapidBuffers_D1: " << rapidBuffers_D1[0][i] << endl;
			}*/
			//cout << "1 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
			a1_clock = 1;
			//cout << "1 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}


		if (a2_clock == 0) {
			p1->get_rapidBuffer(PS5000A_CHANNEL_D, rapidBuffers_D2);
			/*for (int i=0; i != 510; i++)
			{
				cout << "rapidBuffers_D2: " << rapidBuffers_D2[0][i] << endl;
			}*/
			//cout << "2 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
			a2_clock = 1;
			//cout << "2 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}
	}
}
void getdata_thread_A(pico_ctrl* p1, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2) {
	while (st == 0)
	{
		if (a1_clock == 0) {
			p1->get_rapidBuffer(PS5000A_CHANNEL_A, rapidBuffers_A1);
			/*for (int i = 0; i != 510; i++)
			{
				cout << "rapidBuffers_C1: " << rapidBuffers_C1[0][i] << endl;
			}*/
			a1_clock = 1;
			//cout << "1 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}

		
		if (a2_clock == 0) {
			p1->get_rapidBuffer(PS5000A_CHANNEL_A, rapidBuffers_A2);
			/*for (int i=0; i != 510; i++)
			{
				cout << "rapidBuffers_C2: " << rapidBuffers_C2[0][i] << endl;
			}*/

			a2_clock = 1; 
		 //cout << "2 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}
	}
}


void getdata_thread_AC(pico_ctrl* p1, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2) {
	while (st == 0)
	{
		if (a1_clock == 0) {
			p1->get_rapidBuffers(rapidBuffers_A1, rapidBuffers_C1);
			//cout << rapidBuffers_C1[0][100]<<endl;
			a1_clock = 1;
		}

		if (a2_clock == 0) {
			p1->get_rapidBuffers(rapidBuffers_A2, rapidBuffers_C2);
			a2_clock = 1;
	
		}
	}
}
void getdata_thread_AD(pico_ctrl* p1, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2) {
	while (st == 0)
	{
		if (a1_clock == 0) {
			p1->get_rapidBuffer_AD(rapidBuffers_A1, rapidBuffers_D1);
			//cout << rapidBuffers_C1[0][100]<<endl;
			a1_clock = 1;
		}

		if (a2_clock == 0) {
			p1->get_rapidBuffer_AD(rapidBuffers_A2, rapidBuffers_D2);
			a2_clock = 1;

		}
	}
}

void getdata_thread_ACD(pico_ctrl* p1, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2) {
	while (st == 0)
	{
		if (a1_clock == 0) {
			p1->get_rapidBuffers_ACD(rapidBuffers_A1, rapidBuffers_C1, rapidBuffers_D1);
	/*		for (int i = 0; i != 295; i++)
			{
				cout << "rapidBuffers_C1: " <<i<<": " << rapidBuffers_A1[0][i] << endl;
			}*/
			a1_clock = 1;
			//cout << "1 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}
		
		if (a2_clock == 0) {
			p1->get_rapidBuffers_ACD(rapidBuffers_A2, rapidBuffers_C2, rapidBuffers_D2);
			a2_clock = 1;
			//cout << "2 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;

		}
	}
}

void getdata_thread_ABC(pico_ctrl* p1, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2) {
	while (st == 0)
	{
		if (a1_clock == 0) {
			p1->get_rapidBuffers_ABC(rapidBuffers_A1, rapidBuffers_B1, rapidBuffers_C1);
			/*		for (int i = 0; i != 295; i++)
					{
						cout << "rapidBuffers_C1: " <<i<<": " << rapidBuffers_A1[0][i] << endl;
					}*/
			a1_clock = 1;
			//cout << "1 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}

		if (a2_clock == 0) {
			p1->get_rapidBuffers_ABC(rapidBuffers_A2, rapidBuffers_B2, rapidBuffers_C2);
			a2_clock = 1;
			//cout << "2 a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;

		}
	}
}
void getdata_thread_ABCD(pico_ctrl* p1, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2) {
	while (st == 0)
	{
		if (a1_clock == 0) {
			p1->get_rapidBuffers_ABCD(rapidBuffers_A1, rapidBuffers_B1, rapidBuffers_C1, rapidBuffers_D1);
			a1_clock = 1;
			//cout << "1  a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;

		}

		if (a2_clock == 0) {
			p1->get_rapidBuffers_ABCD(rapidBuffers_A2, rapidBuffers_B2, rapidBuffers_C2, rapidBuffers_D2);
			a2_clock = 1;
			//cout << "2  a1_clock:" << a1_clock << "    a2_clock : " << a2_clock << endl;
		}
	}
}
void HPGE_model_deal_thread(pico_ctrl* p1, Param_pals* par, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y_pulse_file_outtxt("./out/HPGe_20230409_pulse.txt", ios::out);
	while (st == 0)
	{
		if (a1_clock == 1) {
			//clock_t t_start, t_stop;
			//t_start = clock();
			//int pass_count = 0;
			bool judge = true;
			double y1[5000] = { 0 };
			double y1_bashline[5000] = { 0 };

			double x[5000] = { 0 };
			for (int i = 0; i < par->n_samples; i++) {
				x[i] = i * p1->pico_timeInterval;
			}
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) 
				{

					y1[sample_k] = rapidBuffers_D1[i_capture][sample_k];
					//cout << "1 a1_clock: " << y1[sample_k] << endl;
				}

#if(judgeway==2)
				judge = tl0->HPGE_shape_filter(lower0, upper0, y1, leftcount, rightcount, par->n_samples);//shape判断脉冲是否符合要求
			
#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				judge = tl0->HPGE_fiexd(y1, leftcount, rightcount, par->n_samples);
#endif


				if (judge) {
					//pass_count += 1;
#if (save_style==1)
					for (int base_i = 0; base_i != par->n_samples; base_i++) {  //主放信号去基线
						y1_bashline[base_i] = y1[base_i] - tl0->base_line_HPGe;
					}
					double E = 0;
					E = tl0->Ge_amp_polnN(x, y1_bashline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << E << "  " << tl0->base_line_HPGe << "  " << tl0->base_line_HPGe_std << endl;

#elif (save_style==0)
					//保存脉冲
					for (int base_i = 0; base_i != par->n_samples; base_i++) {  //主放信号去基线
						y1_bashline[base_i] = y1[base_i] - tl0->base_line_HPGe;
					}
					double E = 0;
					E = tl0->Ge_amp_polnN(x, y1_bashline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << E << "  " << tl0->base_line_HPGe << "  " << tl0->base_line_HPGe_std << endl;

					string string_y1;//初始化为空
					for (int j = 0; j < par->n_samples; j++) {
						if (j == par->n_samples - 1) {
							string_y1 += to_string(int(y1[j]));
						}
						else {
							string_y1 += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
						}
					}
					y_pulse_file_outtxt << string_y1 << endl;

					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			//t_stop = clock();
			//double t01 = (t_stop - t_start);
			//cout << "\n" << "deal time1:" << t01/1000 << " s   " << pass_count <<"个通过" << endl;
			delete tl0;
			a1_clock = 0;

		}

		if (a2_clock == 1) {
			bool judge = true;
			double y1[5000] = { 0 };
			double y1_bashline[5000] = { 0 };
			double x[5000] = { 0 };
			for (int i = 0; i < par->n_samples; i++) {
				x[i] = i * p1->pico_timeInterval;
			}
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) 
				{

					y1[sample_k] = rapidBuffers_D2[i_capture][sample_k];
					//cout << "a2_clock: " << y1[sample_k] << endl;
				}


#if(judgeway==2)
				judge = tl0->HPGE_shape_filter(lower0, upper0, y1, leftcount, rightcount, par->n_samples);//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				judge = tl0->HPGE_fiexd(y1, leftcount, rightcount, par->n_samples);
#endif


				if (judge) {

#if (save_style==1)

					for (int base_i = 0; base_i != par->n_samples; base_i++) {  //主放信号去基线
						y1_bashline[base_i] = y1[base_i] - tl0->base_line_HPGe;

					}
					double E = 0;
					E = tl0->Ge_amp_polnN(x, y1_bashline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << E << "  " << tl0->base_line_HPGe << "  " << tl0->base_line_HPGe_std << endl;

#elif (save_style==0)
					//保存脉冲

					for (int base_i = 0; base_i != par->n_samples; base_i++) {  //主放信号去基线
						y1_bashline[base_i] = y1[base_i] - tl0->base_line_HPGe;

					}
					double E = 0;
					E = tl0->Ge_amp_polnN(x, y1_bashline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << E<<"  "<< tl0->base_line_HPGe <<"  "<< tl0->base_line_HPGe_std<< endl;

					string string_y1;//初始化为空
					for (int j = 0; j < par->n_samples; j++) {

						if (j == par->n_samples - 1) {

							string_y1 += to_string(int(y1[j]));
						}
						else {

							string_y1 += to_string(int(y1[j])) + "  ";//保存HPGE脉冲

						}

					}

					y_pulse_file_outtxt << string_y1 << endl;

					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;


				}
			}
			delete tl0;
			a2_clock = 0;
		}
	}
}

void TAC_model_deal_thread(Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y1_file_outtxt("./out/TAC1_Ach_pulse_TEST_xns_20230323.txt", ios::out);
	while (st == 0)
	{
		if (a1_clock == 1) {
			double y1[5000] = { 0 };
			double T = 0;
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				bool judge = true;
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}

#if(judgeway==2)
				cout<<"TAC model do not have this judgeway model!";
				return ;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				T = tl0->TAC_amplitude_get(y1,par->n_samples, &judge);
#endif


				if (judge) {
#if (save_style==1)

					y01_file_outtxt << T << endl;

#elif (save_style==0)
					//保存脉冲
					string string_y1;//初始化为空
					for (int j = 0; j < par->n_samples; j++) {
						if (j == par->n_samples - 1) {
							string_y1 += to_string(int(y1[j]));
						}
						else {
							string_y1 += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
						}
					}
					y1_file_outtxt << string_y1 << endl;

					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			a1_clock = 0;

		}

		if (a2_clock == 1) {
			double y1[5000] = { 0 };
			double T = 0;
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				bool judge = true;
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return ;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				T = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);
#endif


				if (judge) {
#if (save_style==1)

					y01_file_outtxt << T << endl;

#elif (save_style==0)
					//保存脉冲
					string string_y1;//初始化为空
					for (int j = 0; j < par->n_samples; j++) {
						if (j == par->n_samples - 1) {
							string_y1 += to_string(int(y1[j]));
						}
						else {
							string_y1 += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
						}
					}
					y1_file_outtxt << string_y1 << endl;

					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			a2_clock = 0;
		}
	}
}

void TAC2_model_deal_thread(Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y1_file_outtxt("./out/TAC2_a_pulse20220922.txt", ios::out);
	fstream y2_file_outtxt("./out/TAC2_c_pulse20220922.txt", ios::out);
	while (st == 0)
	{
		if (a1_clock == 1) {
			bool judge1 = true, judge2 = true;
			double y1[5000] = { 0 };
			double y2[5000] = { 0 };
			double T1 = 0, T2=0;
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_C1[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}
				string logic_ch = "none";

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return ;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				//cout<<"该采集模式无该处理模式，请改变judgeway的值";
				return;
#else(judgeway==1)
				judge1 = true, judge2 = true;
				double TAC0 =0, TAC1 = 0;
				T1 = tl0->TAC_amplitude_get(y1, par->n_samples, &judge1);
				TAC0 = tl0->TAC_max;

				T2 = tl1->TAC_amplitude_get(y2, par->n_samples, &judge2);
				TAC1 = tl1->TAC_max;
				//cout << i_capture<<": " << judge1 << "  " << judge2 <<"  " << TAC0 << "  "<< TAC1 << endl;
				if (judge1 == true && judge2 == true) { continue; }
				if (judge1 == true && TAC0 > par->chb_tr && TAC1 < -31000)logic_ch = "b";
				if (judge2 == true && TAC1 > par->chc_tr && TAC0 < -31000)logic_ch = "c";

#endif


				if (logic_ch != "none") {
#if (save_style==1)

					y01_file_outtxt << logic_ch<<"  "<< T1 << "  " << T2 << endl;

#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "a") {
						string string_ya;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_ya += to_string(int(y1[j]));
							}
							else {
								string_ya += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
							}
						}
						y1_file_outtxt << string_ya << endl;
					}
					//保存脉冲

					if (logic_ch == "c") {
						string string_yc;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_yc += to_string(int(y2[j]));
							}
							else {
								string_yc += to_string(int(y2[j])) + "  ";//保存HPGE脉冲
							}
						}
						y2_file_outtxt << string_yc << endl;
					}
					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			delete tl1;
			a1_clock = 0;

		}

		if (a2_clock == 1) {
			bool judge1 = true, judge2 = true;
			double y1[5000] = { 0 };
			double y2[5000] = { 0 };
			double T1 = 0, T2 = 0;
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_C2[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}
				string logic_ch = "none";

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return ;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				//cout << "该采集模式无该处理模式，请改变judgeway的值";
				return;
#else(judgeway==1)
				judge1 = true, judge2 = true;
				double TAC0 = 0, TAC1 = 0;
				T1 = tl0->TAC_amplitude_get(y1, par->n_samples, &judge1);
				TAC0 = tl0->TAC_max;

				T2 = tl1->TAC_amplitude_get(y2, par->n_samples, &judge2);
				TAC1 = tl1->TAC_max;
				if (judge1 == true && judge2 == true) { continue; }
				if (judge1 == true && TAC0 > par->chb_tr && TAC1 < -31000)logic_ch = "b";
				if (judge2 == true && TAC1 > par->chc_tr && TAC0 < -31000)logic_ch = "c";

#endif


				if (logic_ch != "none") {
#if (save_style==1)

					y01_file_outtxt << logic_ch << "  " << T1 << "  " << T2 << endl;

#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "a") {
						string string_ya;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_ya += to_string(int(y1[j]));
							}
							else {
								string_ya += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
							}
						}
						y1_file_outtxt << string_ya << endl;
					}
					//保存脉冲

					if (logic_ch == "c") {
						string string_yc;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_yc += to_string(int(y2[j]));
							}
							else {
								string_yc += to_string(int(y2[j])) + "  ";//保存HPGE脉冲
							}
						}
						y2_file_outtxt << string_yc << endl;
					}
					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
				}
			delete tl0;
			delete tl1;
			a2_clock = 0;

			}
	}
}

void TAC3_model_deal_thread(Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y1_file_outtxt("./out/TAC3_a_pulse8ns.txt", ios::out);
	fstream y2_file_outtxt("./out/TAC3_b_pulse8ns.txt", ios::out);
	fstream y3_file_outtxt("./out/TAC3_c_pulse8ns.txt", ios::out);
	while (st == 0)
	{
		if (a1_clock == 1) {
			bool judge = true;
			double y1[5000] = { 0 };
			double y2[5000] = { 0 };
			double y3[5000] = { 0 };
			double T1 = 0, T2 = 0, T3=0;
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			AMOC_tool* tl2 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_B1[i_capture][sample_k];
					y3[sample_k] = rapidBuffers_C1[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}
				string logic_ch = "none";

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return ;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				double TAC0 = 0, TAC1 = 0, TAC2 = 0;

				T1 = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);
				TAC0 = tl0->TAC_max;

				T2 = tl1->TAC_amplitude_get(y2, par->n_samples, &judge);
			    TAC1 = tl1->TAC_max;

				T3 = tl2->TAC_amplitude_get(y3, par->n_samples, &judge);
				TAC2 = tl2->TAC_max;
				if (TAC0 > par->cha_tr && TAC1 < -31000 && TAC2 < -31000)logic_ch = "a";
				if (TAC1 > par->chb_tr && TAC0 < -31000 && TAC2 < -31000)logic_ch = "b";
				if (TAC2 > par->chc_tr && TAC0 < -31000 && TAC1 < -31000)logic_ch = "c";

#endif


				if (logic_ch != "none") {
#if (save_style==1)

					y01_file_outtxt << logic_ch << "  " << T1 << "  " << T2 << "  " << T3 << endl;

#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "a") {
						string string_ya;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_ya += to_string(int(y1[j]));
							}
							else {
								string_ya += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
							}
						}
						y1_file_outtxt << string_ya << endl;
					}
					//保存脉冲
					if (logic_ch == "b") {
						string string_yb;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_yb += to_string(int(y2[j]));
							}
							else {
								string_yb += to_string(int(y2[j])) + "  ";//保存HPGE脉冲
							}
						}
						y2_file_outtxt << string_yb << endl;
					}
					if (logic_ch == "c") {
						string string_yc;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_yc += to_string(int(y3[j]));
							}
							else {
								string_yc += to_string(int(y3[j])) + "  ";//保存HPGE脉冲
							}
						}
						y3_file_outtxt << string_yc << endl;
					}
					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			delete tl1;
			delete tl2;
			a1_clock = 0;

		}

		if (a1_clock == 1) {
			bool judge = true;
			double y1[5000] = { 0 };
			double y2[5000] = { 0 };
			double y3[5000] = { 0 };
			double T1 = 0, T2 = 0, T3 = 0;
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			AMOC_tool* tl2 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_B2[i_capture][sample_k];
					y3[sample_k] = rapidBuffers_C2[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}
				string logic_ch = "none";

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return ;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				double TAC0 = 0, TAC1 = 0, TAC2 = 0;

				T1 = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);
			    TAC0 = tl0->TAC_max;

				T2 = tl1->TAC_amplitude_get(y2, par->n_samples, &judge);
				TAC1 = tl1->TAC_max;

				T3 = tl2->TAC_amplitude_get(y3, par->n_samples, &judge);
				TAC2 = tl2->TAC_max;
				if (TAC0 > par->cha_tr && TAC1 < -31000 && TAC2 < -31000)logic_ch = "a";
				if (TAC1 > par->chb_tr && TAC0 < -31000 && TAC2 < -31000)logic_ch = "b";
				if (TAC2 > par->chc_tr && TAC0 < -31000 && TAC1 < -31000)logic_ch = "c";

#endif


				if (logic_ch != "none") {
#if (save_style==1)

					y01_file_outtxt << logic_ch << "  " << T1 << "  " << T2 << "  " << T3 << endl;

#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "a") {
						string string_ya;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_ya += to_string(int(y1[j]));
							}
							else {
								string_ya += to_string(int(y1[j])) + "  ";//保存HPGE脉冲
							}
						}
						y1_file_outtxt << string_ya << endl;
					}
					//保存脉冲
					if (logic_ch == "b") {
						string string_yb;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_yb += to_string(int(y2[j]));
							}
							else {
								string_yb += to_string(int(y2[j])) + "  ";//保存HPGE脉冲
							}
						}
						y2_file_outtxt << string_yb << endl;
					}
					if (logic_ch == "c") {
						string string_yc;//初始化为空
						for (int j = 0; j < par->n_samples; j++) {
							if (j == par->n_samples - 1) {
								string_yc += to_string(int(y3[j]));
							}
							else {
								string_yc += to_string(int(y3[j])) + "  ";//保存HPGE脉冲
							}
						}
						y3_file_outtxt << string_yc << endl;
					}
					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			delete tl1;
			delete tl2;
			a1_clock = 0;

			}
	}
}


void AMOC_2CH_thread(pico_ctrl* p1, Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y0_pulse_outtxt("./out/AMOC_2CH_thread_TAC_pulse_20221126.txt", ios::out);
	fstream y1_pulse_outtxt("./out/AMOC_2CH_thread_HPGe_pulse_20221126.txt", ios::out);
	bool judge = true;
	double y0[5000] = { 0 };
	double y1[5000] = { 0 };
	double y_baseline[5000] = { 0 };
	int TAC_start = 0; int TAC_end = 0;
	double T = 0, E = 0;
	
	while (st == 0) {
		//clock_t t1, t2, t3, t4, t5, t6;
		//t1 = t2 = t3 = t4 = t5 = t6 = 0;

		//输出幅度，ai_buf0指针数组保存输出数据
		if (a1_clock == 1) {
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y0[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					y1[sample_k] = rapidBuffers_D1[i_capture][sample_k];
				}

#if(judgeway==2)

				judge = tl0->AMOC_shape_filter(lower0, upper0, y0, y1, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
		//            cout<<judge<<endl;

#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
			    judge = tl0->AMOC_fiexd(y0, y1, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);
				//judge = 1;
#endif

				if (judge)
				{

#if (save_style==1)
					T = tl0->TAC_amplitude(y0, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i*p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y_baseline[base_i] = y1[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y_baseline, par->n_samples,4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;

#elif (save_style==0)

					//保存脉冲
					T = tl0->TAC_amplitude(y0, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}


					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y_baseline[base_i] = y1[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y_baseline, par->n_samples, 4);//保存能量谱

					y01_file_outtxt << T << "  " << E << endl;

					string string_y0, string_y1;//初始化为空
					for (int j = 0; j < par->n_samples; j++)
					{

						if (j == par->n_samples - 1)
						{

							string_y0 += to_string(int(y0[j]));
							string_y1 += to_string(int(y1[j]));
						}
						else
						{

							string_y0 += to_string(int(y0[j])) + "  ";//保存时间谱
							string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

						}

					}
					y0_pulse_outtxt << string_y0 << endl;
					y1_pulse_outtxt << string_y1 << endl;


					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;

				}
			}
			delete tl0;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a1_clock = 0;
		}


		if (a2_clock == 1) {

			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y0[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					y1[sample_k] = rapidBuffers_D2[i_capture][sample_k];
				}

#if(judgeway==2)

				judge = tl0->AMOC_shape_filter(lower0, upper0, y0, y1, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
		//            cout<<judge<<endl;

#elif(judgeway==0)
				judge = true;
#else(judgeway==1)
				judge = tl0->AMOC_fiexd(y0, y1, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);
				//judge = true;
#endif

				if (judge)
				{

#if (save_style==1)
					T = tl0->TAC_amplitude(y0, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y_baseline[base_i] = y1[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y_baseline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;


#elif (save_style==0)
					//保存脉冲
					T = tl0->TAC_amplitude(y0, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y_baseline[base_i] = y1[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y_baseline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;

					string string_y0, string_y1;//初始化为空
					for (int j = 0; j < par->n_samples; j++)
					{

						if (j == par->n_samples - 1)
						{

							string_y0 += to_string(int(y0[j]));
							string_y1 += to_string(int(y1[j]));
						}
						else
						{

							string_y0 += to_string(int(y0[j])) + "  ";//保存时间谱
							string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

						}

					}

					y0_pulse_outtxt << string_y0 << endl;
					y1_pulse_outtxt << string_y1 << endl;

					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;

				}
			}
			delete tl0;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a2_clock = 0;
		}
	}
}

void AMOC_3CH_thread(pico_ctrl* p1, Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y00pulse_file_outtxt("./out/AMOC_3CH_thread_ab_pulse_shape.txt" ,ios::out);
	fstream y01pulse_file_outtxt("./out/AMOC_3CH_thread_ac_pulse_shape.txt", ios::out);
	int num_2 = 0;
	double y00[5000] = { 0 };
	double y01[5000] = { 0 };
	double y1[5000] = { 0 };
	int TAC_start0 = 0; int TAC_end0 = 0, TAC_start1 = 0; int TAC_end1 = 0;
	double T1 = 0, T2 = 0, E = 0;

	while (st == 0) {

		//clock_t t1, t2, t3, t4, t5, t6;
		//t1 = t2 = t3 = t4 = t5 = t6 = 0;

		//输出幅度，ai_buf0指针数组保存输出数据
		if (a1_clock == 1) {
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			int in = 0;
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y00[sample_k] = rapidBuffers_B1[i_capture][sample_k];
					y01[sample_k] = rapidBuffers_C1[i_capture][sample_k];
					y1[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					//cout << y00[sample_k] << "  " << y01[sample_k] << "  " << y1[sample_k] << endl;
				}
				/*
				先观察多路TAC信号再进行处理

				*/
				TAC_start0 = 0; 
				TAC_end0 = 0;
				TAC_start1 = 0; 
				TAC_end1 = 0;
				string logic_ch = "none";
				bool judge1 = true, judge2 = true;
				double y00_max = 0, y01_max = 0;
#if(judgeway==2)
				judge1 = tl0->AMOC_shape_filter(lower0, upper0, y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
				judge2 = tl1->AMOC_shape_filter(lower0, upper0, y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求

				y00_max = tl0->TAC_max;
				y01_max = tl1->TAC_max;
				if (judge1 == true && judge2 == false && y00_max > par->cha_tr && y01_max < -31000)logic_ch = "ad";
				if (judge1 == false && judge2 == true && y00_max < -31000 && y01_max > par->chc_tr)logic_ch = "cd";
				
				/*if (judge1 || judge2)
				{
					in += 1;
					cout <<in<<"    " << judge1 << "    " << judge2 << endl;
				}*/

#elif(judgeway==0)
				//judge1 = true; judge2 = true;
				//y00_max = *max_element(y00, y00 + par->n_samples - 1);
				//y01_max = *max_element(y01, y01 + par->n_samples - 1);
				logic_ch = "0000";

#else(judgeway==1)
				
				
				judge1 = tl0->AMOC_fiexd(y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);
				y00_max = tl0->TAC_max;


				judge2 = tl1->AMOC_fiexd(y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);
				y01_max = tl1->TAC_max;

				/*
				if (judge1 || judge2) 
				{
					in += 1;
					cout <<in<<"    " << judge1 << "    " << judge2 << endl;
				}*/

				if (judge1 == true && judge2 == false && y00_max > par->chb_tr && y01_max < -31000)logic_ch = "ab";
				if (judge1 == false && judge2 == true && y00_max < -31000 && y01_max > par->chc_tr)logic_ch = "ac";
				//cout << i_capture <<": " << y00_max << "  " << y01_max << "  " << judge1 << "  " << judge2 << "  " << logic_ch << endl;
#endif

					if (logic_ch != "none")
				{

#if (save_style==1)
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
							x[i] = i * p1->pico_timeInterval;
					}
					if(logic_ch == "ab"){
					T1 = tl0->TAC_amplitude(y00, TAC_start0, TAC_end0, par->n_samples);//保存时间谱

					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y1[base_i] = y1[base_i] - tl0->base_line_HPGe;
					}
					E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << logic_ch << "  " << T1 << "  " << E << "  " << endl;
					}

					else if(logic_ch == "ac") {
					T2 = tl1->TAC_amplitude(y01, TAC_start1, TAC_end1, par->n_samples);//保存时间谱
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y1[base_i] = y1[base_i] - tl1->base_line_HPGe;
					}
					E = tl1->Ge_amp_polnN(x, y1, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << logic_ch << "  " << T2 << "  " << E << "  " << endl;
					}
					else { cout << "logic_ch  is " << logic_ch << endl; continue; }


#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "ab") {
						string string_y0, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y0 += to_string(int(y00[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y0 += to_string(int(y00[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}

							
						}
						y00pulse_file_outtxt << string_y0 << endl << string_y1 << endl;
					}

					if (logic_ch == "ac") {
						string string_y0, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y0 += to_string(int(y01[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y0 += to_string(int(y01[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}

							
						}
						y01pulse_file_outtxt << string_y0 << endl << string_y1 << endl;
					}


					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;
					num_2++;

				}
			}
			delete tl0 ;
			delete tl1;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a1_clock = 0;
		}

		if (a2_clock == 1) {
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			//int in = 0;
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y00[sample_k] = rapidBuffers_B2[i_capture][sample_k];
					y01[sample_k] = rapidBuffers_C2[i_capture][sample_k];
					y1[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					//cout << y00[sample_k] << "  " << y01[sample_k] << "  " << y1[sample_k] << endl;
				}
				/*
				先观察多路TAC信号再进行处理

				*/

				TAC_start0 = 0;
				TAC_end0 = 0;
				TAC_start1 = 0;
				TAC_end1 = 0;
				string logic_ch = "none";
				bool judge1 = true, judge2 = true;
				double y00_max = 0, y01_max = 0;
#if(judgeway==2)
				judge1 = tl0->AMOC_shape_filter(lower0, upper0, y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
				judge2 = tl1->AMOC_shape_filter(lower0, upper0, y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求

				y00_max = tl0->TAC_max;
				y01_max = tl1->TAC_max;
				if (judge1 == true && judge2 == false && y00_max > par->cha_tr && y01_max < -31000)logic_ch = "ab";
				if (judge1 == false && judge2 == true && y00_max < -31000 && y01_max > par->chc_tr)logic_ch = "ac";
				//            cout<<judge<<endl;

#elif(judgeway==0)
				//judge1 = true; judge2 = true;
				//y00_max = *max_element(y00, y00 + par->n_samples - 1);
				//y01_max = *max_element(y01, y01 + par->n_samples - 1);
				logic_ch = "0000";

#else(judgeway==1)


				judge1 = tl0->AMOC_fiexd(y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);
				y00_max = tl0->TAC_max;


				judge2 = tl1->AMOC_fiexd(y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);
				y01_max = tl1->TAC_max;


				/*if (judge1 || judge2)
				{
					in += 1;
					cout << in << "    " << judge1 << "    " << judge2 << endl;
				}*/

				if (judge1 == true && judge2 == false && y00_max > par->chb_tr && y01_max < -31000)logic_ch = "ab";
				if (judge1 == false && judge2 == true && y00_max < -31000 && y01_max > par->chc_tr)logic_ch = "ac";
				//cout << y00_max <<"  "<< y01_max<<"  " << judge1 << "  " << judge2 << "  " << logic_ch << endl;
#endif

				if (logic_ch != "none")
				{

#if (save_style==1)
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i* p1->pico_timeInterval;
					}
					if (logic_ch == "ab") {
						T1 = tl0->TAC_amplitude(y00, TAC_start0, TAC_end0, par->n_samples);//保存时间谱

						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl0->base_line_HPGe;
						}
						E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 4);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T1 << "  " << E << "  " << endl;
			        }
					else if (logic_ch == "ac") {
						T2 = tl1->TAC_amplitude(y01, TAC_start1, TAC_end1, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl1->base_line_HPGe;
						}
						E = tl1->Ge_amp_polnN(x, y1, par->n_samples, 4);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T2<< "  " << E << "  " << endl;
					}
					else { cout << "logic_ch  is " << logic_ch << endl; break; }



#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "ab") {
						string string_y0, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y0 += to_string(int(y00[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y0 += to_string(int(y00[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y00pulse_file_outtxt << string_y0 << endl << string_y1 << endl;
					}

					if (logic_ch == "ac") {
						string string_y0, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y0 += to_string(int(y01[j]));
								string_y1 += to_string(int(y1[j]));
						}
							else
							{

								string_y0 += to_string(int(y01[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


					}
						y01pulse_file_outtxt << string_y0 << endl << string_y1 << endl;
		}


					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;
					num_2++;

				}
			}
			delete tl0;
			delete tl1;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a2_clock = 0;
		}
	}
}


void AMOC_4CH_thread(pico_ctrl* p1, Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2,int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y00pulse_file_outtxt("./out/AMOC_4CH_thread_ad_pulse_shape.txt", ios::out);
	fstream y01pulse_file_outtxt("./out/AMOC_4CH_thread_bd_pulse_shape.txt", ios::out);
	fstream y02pulse_file_outtxt("./out/AMOC_4CH_thread_cd_pulse_shape.txt", ios::out);
	int num_2 = 0;
	double y00[5000] = { 0 };
	double y01[5000] = { 0 };
	double y02[5000] = { 0 };
	double y1[5000] = { 0 };
	int TAC_start0 = 0; int TAC_end0 = 0;
	int TAC_start1 = 0; int TAC_end1 = 0;
	int TAC_start2 = 0; int TAC_end2 = 0;
	double T0 = 0;
	double T1 = 0;
	double T2 = 0;
	double E = 0;

	while (st == 0) {

		//clock_t t1, t2, t3, t4, t5, t6;
		//t1 = t2 = t3 = t4 = t5 = t6 = 0;

		//输出幅度，ai_buf0指针数组保存输出数据
		if (a1_clock == 1) {
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			AMOC_tool* tl2 = new AMOC_tool();
			int in = 0;
			double x[5000] = { 0 };
			for (int i = 0; i < par->n_samples; i++) {
				x[i] = i * p1->pico_timeInterval;
			}
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y00[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					y01[sample_k] = rapidBuffers_B1[i_capture][sample_k];
					y02[sample_k] = rapidBuffers_C1[i_capture][sample_k];
					y1[sample_k] = rapidBuffers_D1[i_capture][sample_k];
					//cout << y00[sample_k] << "  " << y01[sample_k] << "  " << y1[sample_k] << endl;
				}
				/*
				先观察多路TAC信号再进行处理

				*/
				string logic_ch = "none";
				bool judge1 = true, judge2 = true, judge3 = true;
				TAC_start0 = 0; TAC_end0 = 0;
				TAC_start1 = 0; TAC_end1 = 0;
				TAC_start2 = 0; TAC_end2 = 0;

				T0 = 0;T1 = 0;T2 = 0;E = 0;
				double y00_max = 0, y01_max = 0, y02_max = 0;

#if(judgeway==2)
				judge1 = tl0->AMOC_shape_filter(lower0, upper0, y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
				judge2 = tl1->AMOC_shape_filter(lower0, upper0, y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
				judge3 = tl2->AMOC_shape_filter(lower0, upper0, y02, y1, &TAC_start2, &TAC_end2, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求

				y00_max = tl0->TAC_max;
				y01_max = tl1->TAC_max;
				y02_max = tl2->TAC_max;
		
				if (judge1 == true  && judge2 == false&& judge3 == false && y00_max > par->cha_tr && y01_max < -31000 && y02_max < -31000)logic_ch = "ad";
				if (judge1 == false && judge2 == true && judge3 == false && y00_max < -31000 && y01_max > par->chb_tr && y02_max < -31000)logic_ch = "bd";
				if (judge1 == false && judge2 == false && judge3 == true  && y00_max < -31000 && y01_max < -31000 && y02_max > par->chc_tr)logic_ch = "cd";
				if (judge1 || judge2 || judge3)
				{
					in += 1;
					cout << in << "    " << judge1 << ":" << y00_max << "    " << judge2 << ":" << y01_max<<"    " << judge3<<":" << y02_max << endl;
				}

#elif(judgeway==0)
				//judge1 = true; judge2 = true;
				//y00_max = *max_element(y00, y00 + par->n_samples - 1);
				//y01_max = *max_element(y01, y01 + par->n_samples - 1);
				logic_ch = "0000";

#else(judgeway==1)


				judge1 = tl0->AMOC_fiexd(y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);
				y00_max = tl0->TAC_max;


				judge2 = tl1->AMOC_fiexd(y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);
				y01_max = tl1->TAC_max;

				judge3 = tl2->AMOC_fiexd(y02, y1, &TAC_start2, &TAC_end2, leftcount, rightcount, par->n_samples);
				y02_max = tl2->TAC_max;


	/*			if (judge1 || judge2 ||judge3)
				{
					in += 1;
					cout << in << "    " << judge1 << "    " << judge2 <<"    " << judge3 << endl;
				}*/

				if (judge1 == true && judge2 == false && judge3 == false && y00_max > par->cha_tr && y01_max < -31000 && y02_max < -31000)logic_ch = "ad";
				if (judge1 == false && judge2 == true && judge3 == false && y00_max < -31000 && y01_max > par->chb_tr && y02_max < -31000)logic_ch = "bd";
				if (judge1 == false && judge2 == false && judge3 == true && y00_max < -31000 && y01_max < -31000 && y02_max > par->chc_tr)logic_ch = "cd";
				//cout << y00_max <<"  "<< y01_max<<"  " << judge1 << "  " << judge2 << "  " << logic_ch << endl;
#endif


				if (logic_ch != "none")
				{

#if (save_style==1)

					if (logic_ch == "ad") {
						T0 = tl0->TAC_amplitude(y00, TAC_start0, TAC_end0, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl0->base_line_HPGe;

						}
						E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T0 << "  " << E << "  " << endl;
					}
					else if (logic_ch == "bd") {
						T1 = tl1->TAC_amplitude(y01, TAC_start1, TAC_end1, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl1->base_line_HPGe;

						}
						E = tl1->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T1 << "  " << E << "  " << endl;
					}
					else if (logic_ch == "cd") {
						T2 = tl2->TAC_amplitude(y02, TAC_start2, TAC_end2, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl2->base_line_HPGe;

						}
						E = tl2->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T2 << "  " << E << "  " << endl;
					}
					else { cout << "logic_ch  is " << logic_ch << endl; break; }

					

#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "ad") {

						T0 = tl0->TAC_amplitude(y00, TAC_start0, TAC_end0, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl0->base_line_HPGe;
						}
						E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T0 << "  " << E << "  " << endl;


						string string_y00, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y00 += to_string(int(y00[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y00 += to_string(int(y00[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y00pulse_file_outtxt << string_y00 << endl << string_y1 << endl;
					}
					if (logic_ch == "bd") {
						T1 = tl1->TAC_amplitude(y01, TAC_start1, TAC_end1, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl1->base_line_HPGe;

						}
						E = tl1->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T1 << "  " << E << "  " << endl;


						string string_y01, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y01 += to_string(int(y01[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y01 += to_string(int(y01[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y01pulse_file_outtxt << string_y01 << endl << string_y1 << endl;
					}
					if (logic_ch == "cd") {
						T2 = tl2->TAC_amplitude(y02, TAC_start2, TAC_end2, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl2->base_line_HPGe;

						}
						E = tl2->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T2 << "  " << E << "  " << endl;

						string string_y02, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y02 += to_string(int(y02[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y02 += to_string(int(y02[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y02pulse_file_outtxt << string_y02 << endl << string_y1 << endl;
					}


					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;
					num_2++;

				}
			}
			delete tl0;
			delete tl1;
			delete tl2;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a1_clock = 0;
		}

		if (a2_clock == 1) {
			AMOC_tool* tl0 = new AMOC_tool();
			AMOC_tool* tl1 = new AMOC_tool();
			AMOC_tool* tl2 = new AMOC_tool();
			int in = 0;
			double x[5000] = { 0 };
			for (int i = 0; i < par->n_samples; i++) {
				x[i] = i * p1->pico_timeInterval;
			}
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y00[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					y01[sample_k] = rapidBuffers_B2[i_capture][sample_k];
					y02[sample_k] = rapidBuffers_C2[i_capture][sample_k];
					y1[sample_k] = rapidBuffers_D2[i_capture][sample_k];
					//cout << y00[sample_k] << "  " << y01[sample_k] << "  " << y1[sample_k] << endl;
				}
				/*
				先观察多路TAC信号再进行处理

				*/
				string logic_ch = "none";
				bool judge1 = true, judge2 = true, judge3 = true;

				TAC_start0 = 0; TAC_end0 = 0;
				TAC_start1 = 0; TAC_end1 = 0;
				TAC_start2 = 0; TAC_end2 = 0;

				T0 = 0; T1 = 0; T2 = 0; E = 0;
				double y00_max = 0, y01_max = 0, y02_max = 0;

#if(judgeway==2)
				judge1 = tl0->AMOC_shape_filter(lower0, upper0, y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
				judge2 = tl1->AMOC_shape_filter(lower0, upper0, y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
				judge3 = tl2->AMOC_shape_filter(lower0, upper0, y02, y1, &TAC_start2, &TAC_end2, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求

				y00_max = tl0->TAC_max;
				y01_max = tl1->TAC_max;
				y02_max = tl2->TAC_max;
				if (judge1 == true && judge2 == false && judge3 == false && y00_max > par->cha_tr && y01_max < -31000 && y02_max < -31000)logic_ch = "ad";
				if (judge1 == false && judge2 == true && judge3 == false && y00_max < -31000 && y01_max > par->chb_tr && y02_max < -31000)logic_ch = "bd";
				if (judge1 == false && judge2 == false && judge3 == true && y00_max < -31000 && y01_max < -31000 && y02_max > par->chc_tr)logic_ch = "cd";
				//            cout<<judge<<endl;

#elif(judgeway==0)
				//judge1 = true; judge2 = true;
				//y00_max = *max_element(y00, y00 + par->n_samples - 1);
				//y01_max = *max_element(y01, y01 + par->n_samples - 1);
				logic_ch = "0000";

#else(judgeway==1)


				judge1 = tl0->AMOC_fiexd(y00, y1, &TAC_start0, &TAC_end0, leftcount, rightcount, par->n_samples);
				y00_max = tl0->TAC_max;


				judge2 = tl1->AMOC_fiexd(y01, y1, &TAC_start1, &TAC_end1, leftcount, rightcount, par->n_samples);
				y01_max = tl1->TAC_max;

				judge3 = tl2->AMOC_fiexd(y02, y1, &TAC_start2, &TAC_end2, leftcount, rightcount, par->n_samples);
				y02_max = tl2->TAC_max;


	/*			if (judge1 || judge2 || judge3)
				{
					in += 1;
					cout << in << "    " << judge1 << "    " << judge2 << "    " << judge3 << endl;
				}*/

				if (judge1 == true && judge2 == false && judge3 == false && y00_max > par->cha_tr && y01_max < -31000 && y02_max < -31000)logic_ch = "ad";
				if (judge1 == false && judge2 == true && judge3 == false && y00_max < -31000 && y01_max > par->chb_tr && y02_max < -31000)logic_ch = "bd";
				if (judge1 == false && judge2 == false && judge3 == true && y00_max < -31000 && y01_max < -31000 && y02_max > par->chc_tr)logic_ch = "cd";
				//cout << y00_max <<"  "<< y01_max<<"  " << judge1 << "  " << judge2 << "  " << logic_ch << endl;
#endif

				if (logic_ch != "none")
				{

#if (save_style==1)


					if (logic_ch == "ad") {
						T0 = tl0->TAC_amplitude(y00, TAC_start0, TAC_end0, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl0->base_line_HPGe;

						}
						E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T0 << "  " << E << "  " << endl;
					}
					else if (logic_ch == "bd") {
						T1 = tl1->TAC_amplitude(y01, TAC_start1, TAC_end1, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl1->base_line_HPGe;

						}
						E = tl1->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T1 << "  " << E << "  " << endl;
					}
					else if (logic_ch == "cd") {
						T2 = tl2->TAC_amplitude(y02, TAC_start2, TAC_end2, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl2->base_line_HPGe;

						}
						E = tl2->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T2 << "  " << E << "  " << endl;
					}
					else { cout << "logic_ch  is " << logic_ch << endl; break; }



#elif (save_style==0)
					//保存脉冲
					if (logic_ch == "ad") {
						T0 = tl0->TAC_amplitude(y00, TAC_start0, TAC_end0, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl0->base_line_HPGe;

						}
						E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T0 << "  " << E << "  " << endl;

						string string_y00, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y00 += to_string(int(y00[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y00 += to_string(int(y00[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y00pulse_file_outtxt << string_y00 << endl << string_y1 << endl;
					}
					if (logic_ch == "bd") {

						T1 = tl1->TAC_amplitude(y01, TAC_start1, TAC_end1, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl1->base_line_HPGe;

						}
						E = tl1->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T1 << "  " << E << "  " << endl;


						string string_y01, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y01 += to_string(int(y01[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y01 += to_string(int(y01[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y01pulse_file_outtxt << string_y01 << endl << string_y1 << endl;
					}
					if (logic_ch == "cd") {
						T2 = tl2->TAC_amplitude(y02, TAC_start2, TAC_end2, par->n_samples);//保存时间谱
						for (int base_i = 0; base_i != par->n_samples; base_i++)
						{//主放信号去基线
							y1[base_i] = y1[base_i] - tl2->base_line_HPGe;

						}
						E = tl2->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
						y01_file_outtxt << logic_ch << "  " << T2 << "  " << E << "  " << endl;


						string string_y02, string_y1;//初始化为空
						for (int j = 0; j < par->n_samples; j++)
						{

							if (j == par->n_samples - 1)
							{

								string_y02 += to_string(int(y02[j]));
								string_y1 += to_string(int(y1[j]));
							}
							else
							{

								string_y02 += to_string(int(y02[j])) + "  ";//保存时间谱
								string_y1 += to_string(int(y1[j])) + "  ";//保存能量谱

							}


						}
						y02pulse_file_outtxt << string_y02 << endl << string_y1 << endl;
					}


					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;
					num_2++;

				}
			}
			delete tl0;
			delete tl1;
			delete tl2;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a2_clock = 0;
		}
	}
}
void AMOC_2CH_reconfigurable(pico_ctrl* p1, Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2, int16_t** rapidBuffers_D1, int16_t** rapidBuffers_D2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	//fstream y1_file_outtxt("./out/AMOC_2CH_thread_pulse.txt", ios::out);
	fstream y1_file_outtxt("./out/AMOC_2CH_recon20221202_A_TAC_AMPout_230pre_410Sam_Al2O3.txt", ios::out);
	fstream y2_file_outtxt("./out/AMOC_2CH_recon20221202_B_STARTMON_AMPout_230pre_410Sam_Al2O3.txt", ios::out);
	fstream y3_file_outtxt("./out/AMOC_2CH_recon20221202_C_STOPdynode_AMPout_230pre_410Sam_Al2O3.txt", ios::out);
	fstream y4_file_outtxt("./out/AMOC_2CH_recon20221202_D_HPGe_dynodeAMPout_230pre_410Sam_Al2O3.txt", ios::out);
	int num_2 = 0;
	double y1[5000] = { 0 };
	double y1_Rbaseline[5000] = { 0 };
	double y2[5000] = { 0 };
	double y3[5000] = { 0 };
	double y4[5000] = { 0 };
	double y4_Rbaseline[5000] = { 0 };
	int TAC_start = 0; int TAC_end = 0;
	double T = 0, E = 0;

	while (st == 0) {
		//clock_t t1, t2, t3, t4, t5, t6;
		//t1 = t2 = t3 = t4 = t5 = t6 = 0;

		//输出幅度，ai_buf0指针数组保存输出数据
		if (a1_clock == 1) {
			AMOC_tool* tl0 = new AMOC_tool();
			bool judge = true;
			bool start_judge, stop_judge;
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{

				TAC_start = 0; 
				TAC_end = 0;

				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y1[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_B1[i_capture][sample_k];
					y3[sample_k] = rapidBuffers_C1[i_capture][sample_k];
					y4[sample_k] = rapidBuffers_D1[i_capture][sample_k];
				}

#if(judgeway==2)
				start_judge = tl0->dynode_peak_judge_start(y2, tl0->start_lower, tl0->start_upper, par->n_samples);
				//cout<< i_capture <<"   start_judge: "<< start_judge <<endl;
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_stop(y3, tl0->stop_lower, tl0->stop_upper, par->n_samples);
				//cout << i_capture << "  stop_judge: " << stop_judge << endl;
				if (stop_judge == false) { continue; }
				judge = tl0->AMOC_shape_filter(lower0, upper0, y1, y4, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
		//            cout<<judge<<endl;

#elif(judgeway==0)
				judge = true;
				start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				if (stop_judge == false) { continue; }
#else(judgeway==1)
				//start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				//if (start_judge == false) { continue; }
				//stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				//if (stop_judge == false) { continue; }
				// 
				//start_judge = tl0->dynode_peak_judge_start(y2, tl0->start_lower, tl0->start_upper, par->n_samples);
				////cout<< i_capture <<"   start_judge: "<< start_judge <<endl;
				//if (start_judge == false) { continue; }
				//stop_judge = tl0->dynode_peak_judge_stop(y3, tl0->stop_lower, tl0->stop_upper, par->n_samples);
				////cout << i_capture << "  stop_judge: " << stop_judge << endl;
				//if (stop_judge == false) { continue; }

				judge = tl0->AMOC_fiexd(y1, y4, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);
				//judge = true;
#endif

				if (judge)
				{

#if (save_style==1)
					T = tl0->TAC_amplitude(y1, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y4_Rbaseline[base_i] = y4[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y4_Rbaseline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;

#elif (save_style==0)
					//保存脉冲

					//cout << "i_capture1: " << i_capture << endl;
					T = tl0->TAC_amplitude(y1, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y4_Rbaseline[base_i] = y4[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y4_Rbaseline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;



					string string_y1, string_y2, string_y3, string_y4;//初始化为空
					for (int j = 0; j < par->n_samples; j++)
					{

						if (j == par->n_samples - 1)
						{

							string_y1 += to_string(int(y1[j]));
							string_y2 += to_string(int(y2[j]));
							string_y3 += to_string(int(y3[j]));
							string_y4 += to_string(int(y4[j]));
						}
						else
						{

							string_y1 += to_string(int(y1[j])) + "  ";//保存时间谱
							string_y2 += to_string(int(y2[j])) + "  ";//保存START 能谱
							string_y3 += to_string(int(y3[j])) + "  ";//保存STOP 能谱
							string_y4 += to_string(int(y4[j])) + "  ";//保存能量谱

						}

					}
					//y1_file_outtxt << string_y0 << endl << string_y1 << endl;
					y1_file_outtxt << string_y1 << endl;
					y2_file_outtxt << string_y2 << endl;
					y3_file_outtxt << string_y3 << endl;
					y4_file_outtxt << string_y4 << endl;

					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;
					num_2++;

				}
			}
			delete tl0;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a1_clock = 0;
		}


		if (a2_clock == 1) {
			bool start_judge, stop_judge;
			bool judge = true;
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{

				TAC_start = 0;
				TAC_end = 0;
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {
					y1[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_B2[i_capture][sample_k];
					y3[sample_k] = rapidBuffers_C2[i_capture][sample_k];
					y4[sample_k] = rapidBuffers_D2[i_capture][sample_k];
				}

#if(judgeway==2)
				start_judge = tl0->dynode_peak_judge_start(y2, tl0->start_lower, tl0->start_upper, par->n_samples);
				//cout<< i_capture <<"   start_judge: "<< start_judge <<endl;
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_stop(y3, tl0->stop_lower, tl0->stop_upper, par->n_samples);
				//cout << i_capture << "  stop_judge: " << stop_judge << endl;
				if (stop_judge == false) { continue; }
				judge = tl0->AMOC_shape_filter(lower0, upper0, y1, y4, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);//判断脉冲是否符合要求
		//            cout<<judge<<endl;

#elif(judgeway==0)
				judge = true;
				start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				if (stop_judge == false) { continue; }
#else(judgeway==1)

				//start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				//if (start_judge == false) { continue; }
				//stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				//if (stop_judge == false) { continue; }

				//start_judge = tl0->dynode_peak_judge_start(y2, tl0->start_lower, tl0->start_upper, par->n_samples);
				////cout<< i_capture <<"   start_judge: "<< start_judge <<endl;
				//if (start_judge == false) { continue; }
				//stop_judge = tl0->dynode_peak_judge_stop(y3, tl0->stop_lower, tl0->stop_upper, par->n_samples);
				////cout << i_capture << "  stop_judge: " << stop_judge << endl;
				//if (stop_judge == false) { continue; }
				judge = tl0->AMOC_fiexd(y1, y4, &TAC_start, &TAC_end, leftcount, rightcount, par->n_samples);

#endif

				if (judge)
				{

#if (save_style==1)

					T = tl0->TAC_amplitude(y1, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y4_Rbaseline[base_i] = y4[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y4_Rbaseline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;

#elif (save_style==0)
					//保存脉冲

					//cout << "i_capture2: " << i_capture << endl;
					T = tl0->TAC_amplitude(y1, TAC_start, TAC_end, par->n_samples);//保存时间谱
					double x[5000] = { 0 };
					for (int i = 0; i < par->n_samples; i++) {
						x[i] = i * p1->pico_timeInterval;
					}
					for (int base_i = 0; base_i != par->n_samples; base_i++)
					{//主放信号去基线
						y4_Rbaseline[base_i] = y4[base_i] - tl0->base_line_HPGe;

					}
					E = tl0->Ge_amp_polnN(x, y4_Rbaseline, par->n_samples, 4);//保存能量谱
					y01_file_outtxt << T << "  " << E << endl;


					string string_y1, string_y2, string_y3, string_y4;//初始化为空
					for (int j = 0; j < par->n_samples; j++)
					{

						if (j == par->n_samples - 1)
						{
							string_y1 += to_string(int(y1[j]));
							string_y2 += to_string(int(y2[j]));
							string_y3 += to_string(int(y3[j]));
							string_y4 += to_string(int(y4[j]));
						}
						else
						{

							string_y1 += to_string(int(y1[j])) + "  ";//保存时间谱
							string_y2 += to_string(int(y2[j])) + "  ";//保存START 能谱
							string_y3 += to_string(int(y3[j])) + "  ";//保存STOP 能谱
							string_y4 += to_string(int(y4[j])) + "  ";//保存能量谱

						}

					}

					//y1_file_outtxt << string_y0 << endl << string_y1 << endl;
					y1_file_outtxt << string_y1 << endl;
					y2_file_outtxt << string_y2 << endl;
					y3_file_outtxt << string_y3 << endl;
					y4_file_outtxt << string_y4 << endl;

					//保存脉冲

#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					//cout << "judge2" << judge << "   a1_clock: " << a1_clock << "  a2_clock: " << a2_clock << "     st: " << st << "    num_0:" << num_0 << endl;
					num_0++;
					num_2++;

				}
			}
			delete tl0;
			//t4 = clock();
			//cout << "   count rate:" << CLOCKS_PER_SEC * num_2 / double(t4 - t3) << "   num_0:" << num_0 << endl;
			a2_clock = 0;
		}
	}
}
void singleTAC_reconfigurable(Param_pals* par, int16_t** rapidBuffers_A1, int16_t** rapidBuffers_A2, int16_t** rapidBuffers_B1, int16_t** rapidBuffers_B2, int16_t** rapidBuffers_C1, int16_t** rapidBuffers_C2)
{
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	fstream y1_pulsefile_outtxt("./out/singleSCA_recon20221128_A_TAC_AMPout_230pre_360Sam_YSZ_300W.txt", ios::out);
	fstream y2_pulsefile_outtxt("./out/singleTAC_recon20221128_B_STARTMON_AMPout_230pre_360Sam_YSZ_300W.txt", ios::out);
	fstream y3_pulsefile_outtxt("./out/singleTAC_recon20221128_C_STOPdynode_AMPout_230pre_360Sam_YSZ_300W.txt", ios::out);
	while (st == 0)
	{
		if (a1_clock == 1) {
			bool judge = true;
			double y1[5000] = { 0 };
			double y2[5000] = { 0 };
			double y3[5000] = { 0 };
			double T = 0;
			bool start_judge, stop_judge;
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{

				judge = true;
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A1[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_B1[i_capture][sample_k];
					y3[sample_k] = rapidBuffers_C1[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
				start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				if (stop_judge == false) { continue; }
#else(judgeway==1)

				//start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				//if (start_judge == false) { continue; }
				//stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				//if (stop_judge == false) { continue; }


				start_judge = tl0->dynode_peak_judge_start(y2, tl0->start_lower, tl0->start_upper, par->n_samples);
				//cout<< i_capture <<"   start_judge: "<< start_judge <<endl;
				if (start_judge == false) {continue;}
				stop_judge = tl0->dynode_peak_judge_stop(y3, tl0->stop_lower, tl0->stop_upper, par->n_samples);
				//cout << i_capture << "  stop_judge: " << stop_judge << endl;
				if (stop_judge == false) { continue; }

				T = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);

#endif


				if (judge) {
#if (save_style==1)

					y01_file_outtxt << T << endl;

#elif (save_style==0)
					//保存脉冲
					T = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);
					y01_file_outtxt << T << endl;
					string string_y1, string_y2, string_y3;//初始化为空
					for (int j = 0; j < par->n_samples; j++) {
						if (j == par->n_samples - 1) {
							string_y1 += to_string(int(y1[j]));
							string_y2 += to_string(int(y2[j]));
							string_y3 += to_string(int(y3[j]));
						}
						else {
							string_y1 += to_string(int(y1[j])) + "  ";//
							string_y2 += to_string(int(y2[j])) + "  ";//
							string_y3 += to_string(int(y3[j])) + "  ";//
						}
					}
					y1_pulsefile_outtxt << string_y1 << endl;
					y2_pulsefile_outtxt << string_y2 << endl;
					y3_pulsefile_outtxt << string_y3 << endl;

					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			a1_clock = 0;

		}

		if (a2_clock == 1) {
			bool judge = true;
			double y1[5000] = { 0 };
			double y2[5000] = { 0 };
			double y3[5000] = { 0 };
			double T = 0;
			bool start_judge, stop_judge;
			AMOC_tool* tl0 = new AMOC_tool();
			for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
			{

				judge = true;
				for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

					y1[sample_k] = rapidBuffers_A2[i_capture][sample_k];
					y2[sample_k] = rapidBuffers_B2[i_capture][sample_k];
					y3[sample_k] = rapidBuffers_C2[i_capture][sample_k];
					//cout << "a1_clock: " << y1[sample_k] << endl;
				}

#if(judgeway==2)
				cout << "TAC model do not have this judgeway model!";
				return;//shape判断脉冲是否符合要求
#elif(judgeway==0)
				judge = true;
				start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				if (stop_judge == false) { continue; }
#else(judgeway==1)
				//start_judge = tl0->dynode_peak_judge_baseline_start(y2);
				//if (start_judge == false) { continue; }
				//stop_judge = tl0->dynode_peak_judge_baseline_stop(y3);
				//if (stop_judge == false) { continue; }

				start_judge = tl0->dynode_peak_judge_start(y2, tl0->start_lower, tl0->start_upper, par->n_samples);
				if (start_judge == false) { continue; }
				stop_judge = tl0->dynode_peak_judge_stop(y3, tl0->stop_lower, tl0->stop_upper, par->n_samples);
				if (stop_judge == false) { continue; }
				T = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);
#endif


				if (judge) {
#if (save_style==1)

					y01_file_outtxt << T << endl;

#elif (save_style==0)
					//保存脉冲
					T = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);
					y01_file_outtxt << T << endl;
					string string_y1, string_y2, string_y3;//初始化为空
					for (int j = 0; j < par->n_samples; j++) {
						if (j == par->n_samples - 1) {
							string_y1 += to_string(int(y1[j]));
							string_y2 += to_string(int(y2[j]));
							string_y3 += to_string(int(y3[j]));
						}
						else {
							string_y1 += to_string(int(y1[j])) + "  ";//
							string_y2 += to_string(int(y2[j])) + "  ";//
							string_y3 += to_string(int(y3[j])) + "  ";//
						}
					}
					y1_pulsefile_outtxt << string_y1 << endl;
					y2_pulsefile_outtxt << string_y2 << endl;
					y3_pulsefile_outtxt << string_y3 << endl;

					//保存脉冲
#else
					cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
					num_0++;

				}
			}
			delete tl0;
			a2_clock = 0;
		}
	}
}

void HPGe(pico_ctrl* p1, Param_pals* par, int16_t** rapidBuffers_D1) {
	fstream y01_file_outtxt(par->outfile_name, ios::out);
	double y1[5000] = { 0 };
	AMOC_tool* tl0 = new AMOC_tool();
	int count = 0;
	while (st == 0) {

		clock_t t1, t2, t3, t4, t5, t6;
		t1 = t2 = t3 = t4 = t5 = t6 = 0;

		int num_2 = 0;
		count += 1;
		cout << "count: " << count;
		t1 = clock();
		p1->get_rapidBuffer(PS5000A_CHANNEL_C, rapidBuffers_D1);
		//p1->get_rapidBuffers(rapidBuffers_A1, rapidBuffers_C1);
		t2 = clock();
		int count1 = 0;
		for (int i_capture = 0; i_capture < par->n_captures; i_capture++)
		{

			bool judge = true;
			for (int sample_k = 0; sample_k < par->n_samples; sample_k++) {

				y1[sample_k] = rapidBuffers_D1[i_capture][sample_k];
			}

#if(judgeway==2)
			judge = tl0->HPGE_shape_filter(lower0, upper0, y1, leftcount, rightcount, par->n_samples);//shape判断脉冲是否符合要求
#elif(judgeway==0)
			judge = true;

#else(judgeway==1)
			judge = tl0->HPGE_fiexd(y1, leftcount, rightcount, par->n_samples);
			//double T = tl0->TAC_amplitude_get(y1, par->n_samples, &judge);

			//cout << "judge: " << judge <<"   T: "<<T << endl;

#endif


			if (judge) {
#if (save_style==1)
				double x[5000] = { 0 };
				for (int i = 0; i < par->n_samples; i++) {
					x[i] = i;
				}
				for (int base_i = 0; base_i != par->n_samples; base_i++) {  //主放信号去基线
					y1[base_i] = y1[base_i] - tl0->base_line_HPGe;
				}
				double E = 0;
				E = tl0->Ge_amp_polnN(x, y1, par->n_samples, 3);//保存能量谱
				y01_file_outtxt << E << endl;

#elif (save_style==0)
				//保存脉冲
				string string_y1;//初始化为空
				t3 = clock();
				for (int j = 0; j < par->n_samples; j++) {
					if (j == par->n_samples - 1) {
						string_y1 += to_string(int(y1[j]));
					}
					else {
						string_y1 += to_string(int(y1[j])) + "  ";//保存hpge脉冲
					}
				}

				y01_file_outtxt << string_y1 << endl;
				t4 = clock();
				//保存脉冲
#else
				cout << "pealse set the save_style correctly!" << endl; return 0;
#endif
				num_0++;
				num_2++;


			}

		}

		//delete tl0;
		t5 = clock();
#if (save_style==1)
		cout << "HPGE amplitude count rate: " << int(CLOCKS_PER_SEC * num_2 / double(t2 - t1)) << "  第一轮未过计数:" << count1 << "    计数: " << num_0 << endl;//程序采集效率，脉冲/秒
#elif (save_style==0)

		cout << "TAC or HPGe pulse count rate: " << int(CLOCKS_PER_SEC * num_2 / double(t5 - t1)) << "  num_2: " << num_2 << "  t5 - t1: " << double(t5 - t1) / CLOCKS_PER_SEC <<
			"     计数: " << num_0 << "   buffer time:" << (double(t2 - t1) / CLOCKS_PER_SEC) <<
			"   each deal time:" << fixed << setprecision(6) << (double(t4 - t3) / CLOCKS_PER_SEC) <<
			"     deal time:" << (double(t5 - t2) / CLOCKS_PER_SEC) << endl;//程序采集效率，脉冲/秒
#endif

		if (num_0 > par->total_count) st = 1;

	}
}

//读取形状甄别器
void get_shape()
{
	const char* low_upper_name = "./gaussfiti_shape_pulse.txt";
	string line;
	fstream file_shape0(low_upper_name, ios::in);

	int lk = 0;
	cout << "\n形状甄别器: " << endl;
	while (getline(file_shape0, line))
	{
		istringstream sin(line);
		sin >> lower0[lk] >> upper0[lk];

		cout <<lk<<": " << lower0[lk] << "   " << upper0[lk] << endl;
		++lk;
		if (lk > pulse_wide) { cout<<"读取甄别器错误或数组维度设置不正确" << endl; }
	}
}

//多线程时计数
void cps2(int t_counts) {
	int n1, n2;
	while (st == 0) {
		n1 = num_0;
		Sleep(60000);
		n2 = num_0;
		cout <<"Count Rate: " << (double)(n2 - n1) /60 << "    Counts: " << num_0 << endl;
		if (num_0 > t_counts) st = 1;
	}
}
int32_t main(void)
{
	a1_clock = c1_clock = a2_clock = c2_clock = 0;
	st = 0;

	pico_ctrl* p1 = new pico_ctrl(2);
	Param_pals* par = new Param_pals;
	Get_parameters* getp = new Get_parameters();
	getp->set_para(par);//参数附初值
	getp->read_in("input.ini", par);

	//channelSettings结构体设置
	int m5 = 0;
	m5 = p1->channelSetting_in(0, par->cha, par->cha_r, par->cha_offset);
	m5 = p1->channelSetting_in(1, par->chb, par->chb_r, par->chb_offset);
	m5 = p1->channelSetting_in(2, par->chc, par->chc_r, par->chc_offset);
	m5 = p1->channelSetting_in(3, par->chd, par->chd_r, par->chd_offset);

	p1->nCaptures = par->n_captures;
	p1->timebase_0 = par->timebase0;
	//cout <<"p1->timebase_0 1: " << p1->timebase_0 << endl;
	p1->set_samples(par->n_samples, par->n_presamples);
	//cout << "p1->timebase_0 1: " << p1->timebase_0 << endl;
	//寻找设备并且设置每个通道参数
	m5 = p1->pico_find_and_setting();
	if (m5 == 1) { return 0; }
	cout << "p1->timebase_0 1: " << p1->timebase_0 << endl;
	m5 = p1->set_memory();

	//trigger set
	if (par->tri_mode == "CHA_T") {
		m5 = p1->set_simpletrigger(PS5000A_CHANNEL_A, PS5000A_RISING, par->cha_tr, 0);
	}
	else if (par->tri_mode == "CHB_T") {
		m5 = p1->set_simpletrigger(PS5000A_CHANNEL_B, PS5000A_RISING, par->chb_tr, 0);
	}
	else if (par->tri_mode == "CHC_T") {
		m5 = p1->set_simpletrigger(PS5000A_CHANNEL_C, PS5000A_RISING, par->chc_tr, 0);
	}
	else if (par->tri_mode == "CHD_T") {
		m5 = p1->set_simpletrigger(PS5000A_CHANNEL_D, PS5000A_RISING, par->chd_tr, 0);
	}
	else if (par->tri_mode == "EXT") {
		m5 = p1->set_simpletrigger(PS5000A_EXTERNAL, PS5000A_RISING, par->chd_tr, 0);
	}
	else if (par->tri_mode == "AC_T") {
		m5 = p1->set_ACORtrigger(PS5000A_RISING, par->cha_tr, par->chc_tr);
	}
	else if (par->tri_mode == "AB_T") {
		m5 = p1->set_ABORtrigger(PS5000A_RISING, par->cha_tr, par->chb_tr);
	}
	else if (par->tri_mode == "BC_T") {
		m5 = p1->set_BCORtrigger(PS5000A_RISING, par->chb_tr, par->chc_tr);
	}
	else if (par->tri_mode == "ABC_T") {
		m5 = p1->set_ABCORtrigger(PS5000A_RISING, par->cha_tr, par->chb_tr, par->chc_tr);
	}
	else { cout << "pelase set up trigger correctly!!!" << endl;return 0; }

	//bufferset
	int16_t** rapidBuffers_A1;
	int16_t** rapidBuffers_B1;
	int16_t** rapidBuffers_C1;
	int16_t** rapidBuffers_D1;
	int16_t** rapidBuffers_A2;
	int16_t** rapidBuffers_B2;
	int16_t** rapidBuffers_C2;
	int16_t** rapidBuffers_D2;
	rapidBuffers_A1 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_B1 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_C1 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_D1 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_A2 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_B2 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_C2 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));
	rapidBuffers_D2 = (int16_t**)calloc(p1->nCaptures, sizeof(int16_t*));


	int capture;
	for (capture = 0; capture < p1->nCaptures; capture++)
	{
		rapidBuffers_A1[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_B1[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_C1[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_D1[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_A2[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_B2[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_C2[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
		rapidBuffers_D2[capture] = (int16_t*)calloc(p1->nSamples, sizeof(int16_t));
	}
#if(judgeway==2)
	get_shape();
#endif
	clock_t t_start, t_stop;
	t_start = clock();
	//单线程
	/*if (par->get_d == "single_mode" && par->meas_mode == "HPGE") {
		HPGe(p1, par, rapidBuffers_D1);
	}

	else if (par->get_d == "single_mode" && par->meas_mode == "AMOC") {
		AMOC_2CH(p1, par, rapidBuffers_A1, rapidBuffers_D1);
	}
	else if (par->get_d == "AC_MODE" && par->meas_mode == "AMOC") {
		AMOC_3CH(p1, par, rapidBuffers_A1, rapidBuffers_C1, rapidBuffers_D1);
	}
	else cout << "pealse input \"get_d\" paramenter correctly！" << endl;*/


	//双线程采集HPGe
	thread* first = NULL;
	thread* second = NULL;
	if (par->get_d == "singleHPGE_mode") {
		cout << "\n  singleHPGE_mode  " << endl;
		first = new thread(getdata_thread_A, p1, rapidBuffers_A1, rapidBuffers_A2);
		//first = new thread(getdata_thread_ABCD, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
		second = new thread(HPGE_model_deal_thread, p1, par, rapidBuffers_A1, rapidBuffers_A2);
	}

	if (par->get_d == "singleTAC_mode") {
		cout << "\n  singleTAC_mode  " << endl;
		first = new thread(getdata_thread_A, p1, rapidBuffers_A1, rapidBuffers_A2);
		second = new thread(TAC_model_deal_thread, par, rapidBuffers_C1, rapidBuffers_C2);

	}
	if (par->get_d == "2TAC_mode") {
		cout << "\n  2TAC_mode  " << endl;
		//first = new thread(getdata_thread_ABC, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);

		first = new thread(getdata_thread_AC, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_C1, rapidBuffers_C2);
		second = new thread(TAC2_model_deal_thread, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_C1, rapidBuffers_C2);
	}

	if (par->get_d == "3TAC_mode") {
		cout << "\n  3TAC_mode  " << endl;
		first = new thread(getdata_thread_ABC, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);
		second = new thread(TAC3_model_deal_thread, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);
	}

	if (par->get_d == "AMOC_2CH_thread") {
		cout << "\n  AMOC_2CH_thread  " << endl;
		first = new thread(getdata_thread_AD, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_D1, rapidBuffers_D2);
		second = new thread(AMOC_2CH_thread, p1, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_D1, rapidBuffers_D2);
	}
	if (par->get_d == "AMOC_3CH_thread") {
		cout << "\n  AMOC_3CH_thread  " << endl;
		first = new thread(getdata_thread_ABC, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);
		second = new thread(AMOC_3CH_thread, p1, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);
	}

	if (par->get_d == "AMOC_4CH_thread") {
		cout << "\n  AMOC_4CH_thread  " << endl;
		first = new thread(getdata_thread_ABCD, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
		second = new thread(AMOC_4CH_thread, p1, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
	}

	if (par->get_d == "singleTAC_reconfigurable") {
		cout << "\n  singleTAC_reconfigurable  " << endl;
		first = new thread(getdata_thread_ABC, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);
		second = new thread(singleTAC_reconfigurable, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2);

	}
	if (par->get_d == "AMOC_2CH_reconfigurable") {
		cout << "\n  AMOC_2CH_reconfigurable   " << endl;
		first = new thread(getdata_thread_ABCD, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
		second = new thread(AMOC_2CH_reconfigurable, p1, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_B1, rapidBuffers_B2, rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
	}
	//thread* first = NULL;
	//first = new thread(getdata_thread_c, p1, rapidBuffers_C1, rapidBuffers_C2);
	//first = new thread(getdata_thread_ACD, p1, rapidBuffers_A1, rapidBuffers_A2 ,rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
	//first = new thread(getdata_thread_AC, p1, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_C1, rapidBuffers_C2);
	//thread* second = NULL;
	//second = new thread(HPGE_model_deal_thread, par, rapidBuffers_C1, rapidBuffers_C2);
	//second = new thread(AMOC_3CH_thread, p1, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_C1, rapidBuffers_C2, rapidBuffers_D1, rapidBuffers_D2);
	//second - new thread(AMOC_2CH_thread, p1, par, rapidBuffers_A1, rapidBuffers_A2, rapidBuffers_C1, rapidBuffers_C2);
	thread third(cps2, par->total_count);
	first->join();
	second->join();
	third.join();

	t_stop = clock();
	double t01 = (t_stop - t_start);
	cout << "\n" << "Count Rate:" << 1000 * (double)num_0 / t01 << " cps" << endl;
	p1->pico_close();

	cout << "execution time:" << int(double(t_stop - t_start) / CLOCKS_PER_SEC) << " S  测试完成" << endl;
	return 0;
}