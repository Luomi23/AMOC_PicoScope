#include "AMOC_tool.h"
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "interpolation.h"
#include <cmath>
#include <iostream>
#include <fstream>
#include <numeric>
#include<algorithm>
#include <iomanip>
#include <cstdlib>
#include <string>
using namespace alglib;
using namespace std;
//static������ʼ��

int AMOC_tool::num_width = 10;
double AMOC_tool::delta_HPGe = 300;
int AMOC_tool::HPGejudge_num = 10;
double AMOC_tool::base_line_HPGe_std_thouread = 34;

int AMOC_tool::TAC_flatop_std = 29.1;
int AMOC_tool::delta_A = 300;
//dynode����������
int AMOC_tool::start_initial_position = 117;
int AMOC_tool::stop_initial_position = 116;

int AMOC_tool::start_lower = 23014;
int AMOC_tool::start_upper = 34199;
int AMOC_tool::stop_lower = 24159;
int AMOC_tool::stop_upper = 34265;

int AMOC_tool::leftcount = int(80/3);
int AMOC_tool::rightcount = int(60/3);
int AMOC_tool::fit_leftcount = int(25/3);
int AMOC_tool::fit_rightcount = int(15/3);

//����ִ��AMOC_judge��Ա�������жϱ������������Ƿ�ͨ��
//���캯�����޷���ֵ���ڴ�������ʱ�Զ�ִ��
AMOC_tool::AMOC_tool() {

	base_line_HPGe = -26000;
	amp_max = 32767;
	max_ch_HPGe = 300;
	base_line_HPGe_std = 10000;

}

//�����������޷���ֵ�������ٶ���ʱ�Զ�ִ��
AMOC_tool::~AMOC_tool() {

}
double AMOC_tool::Ge_amp_polnN(double* x0, double* y0, int scancount, int poln) {
	double max_0 = -32767;
	int x_n = 0;
	double m_1 = 0;
	int end_n = scancount;
	/*for (int i = max_ch_HPGe; i < scancount; i++) {
		if (y0[i] == -32512 || y0[i] < -32512) {
			end_n = i;
			break;
		}
	}*/

		real_1d_array x1;
		real_1d_array y1;
		if (max_ch_HPGe< num_width || max_ch_HPGe > scancount - num_width) {
			cout << "HPGe�������ֵλ������������������ʱ��bug��ʾ" << endl;
			return -32767;

		}
		x1.setcontent(2 * num_width, &x0[max_ch_HPGe - num_width ]);
		y1.setcontent(2 * num_width, &y0[max_ch_HPGe - num_width ]);
		ae_int_t m = poln + 1;
		ae_int_t info;
		barycentricinterpolant p;
		polynomialfitreport rep;
		//����ʽ���
		polynomialfit(x1, y1, m, info, p, rep);
		if (info <= 0) { return -32768; }
		m_1 = barycentriccalc(p, x0[max_ch_HPGe - (num_width+1)]);
		for (int i = max_ch_HPGe - num_width; i < max_ch_HPGe + num_width; i++) {
			double m0;
			m0 = barycentriccalc(p, x0[i]);
			if (m0 > max_0) {
				max_0 = m0;
				x_n = i;
			}
			//if (m0 < m_1) break;
			//m_1 = m0;
		}
		double a0 = (x0[1] - x0[0]) / 50;
		double A1 = 0;
		m_1 = barycentriccalc(p, x0[x_n - 1] - a0);
		for (double a1 = x0[x_n - 1]; a1 < x0[x_n + 1]; a1 = a1 + a0) {
			double m0;
			m0 = barycentriccalc(p, a1);
			A1 = a1;
			if (m0 > max_0) {
				max_0 = m0;
			}
			if (m0 < m_1) break;
			m_1 = m0;
		}
		//cout<<"max_0: "<<max_0<<"    " << x0[x_n - 1] << "     " << a0 << "    " << A1 <<"    "<< barycentriccalc(p, x0[x_n - 1]-a0) <<"  "<< barycentriccalc(p, x0[x_n - 1]) << endl;
		//cout  << max_0 << "  " << max_ch_HPGe <<"  " << amp_max << "  " << base_line_HPGe << endl<<endl;
		return max_0;

}

double AMOC_tool::Ge_amp_poln_fitrange(double* x0, double* y0, int maxposition, double max_0, int poln) {

	int x_n = maxposition;
	double m_1;

	real_1d_array x1;
	real_1d_array y1;
	x1.setcontent(fit_leftcount + fit_rightcount, x0);
	y1.setcontent(fit_leftcount + fit_rightcount, y0);
	ae_int_t m = poln + 1;
	ae_int_t info;
	barycentricinterpolant p;
	polynomialfitreport rep;
	//����ʽ���
	polynomialfit(x1, y1, m, info, p, rep);
	if (info <= 0 ) {return -32768;}
	double a0 = (x0[1] - x0[0]) / 50;
	m_1 = barycentriccalc(p, x0[x_n - 1] - a0);
	for (double a1 = x0[x_n - 1]; a1 < x0[x_n + 1]; a1 = a1 + a0) {
		double m0;
		m0 = barycentriccalc(p, a1);
		if (m0 > max_0) {
			max_0 = m0;
		}
		if (m0 < m_1) break;
		m_1 = m0;
	}
	return max_0;

}
bool AMOC_tool::dynode_peak_judge_baseline_start(double* reslist_dynode) 
{
	double baseline_ave = (double)accumulate(reslist_dynode + 0, reslist_dynode + 50, 0.0) / 50;
	if (baseline_ave < -6980 || baseline_ave > -5980) { return false; }
	double sum_std = 0;
	for (int i = 0; i != 50; i++) {
		sum_std = pow((reslist_dynode[i] - baseline_ave), 2) + sum_std;
	}
	double baseline_std = pow(sum_std / 50, 0.5);
	if (baseline_std > 550) { return false; }
	return true;

}

bool AMOC_tool::dynode_peak_judge_baseline_stop(double* reslist_dynode)
{
	double baseline_ave = (double)accumulate(reslist_dynode + 0, reslist_dynode + 50, 0.0) / 50;
	if (baseline_ave < -13625 || baseline_ave > -12605) { return false; }
	double sum_std = 0;
	for (int i = 0; i != 50; i++) {
		sum_std = pow((reslist_dynode[i] - baseline_ave), 2) + sum_std;
	}
	double baseline_std = pow(sum_std / 50, 0.5);
	if (baseline_std > 550) { return false; }
	return true;

}

bool AMOC_tool::dynode_peak_judge_start(double* reslist_dynode, double lower_value, double super_value, int SCANCOUNT)
{
	double* reslist_dynode1 = (double*)calloc(leftcount + rightcount, sizeof(double));
	double baseline = (double)accumulate(reslist_dynode + 0, reslist_dynode + 50, 0.0) / 50;
	for (int i = start_initial_position- leftcount; i != start_initial_position + rightcount; i++) {
		reslist_dynode1[i- (start_initial_position - leftcount)] = reslist_dynode[i]- baseline;
	}
	double maxValuey0= *max_element(reslist_dynode1, reslist_dynode1 + leftcount + rightcount);

	if (maxValuey0 < start_lower|| maxValuey0 > start_upper) { return false; }


	/*int maxpositiony0 = max_element(reslist_dynode1, reslist_dynode1 + leftcount + rightcount) - reslist_dynode1;
	if(maxpositiony0 - fit_leftcount < 0 || maxpositiony0 + fit_rightcount > leftcount + rightcount){ return false; }

	double* reslist_dynode_fit = (double*)calloc(fit_leftcount + fit_rightcount, sizeof(double));
	double* x = (double*)calloc(fit_leftcount + fit_rightcount, sizeof(double));
	for (int i = maxpositiony0 - fit_leftcount; i != maxpositiony0 + fit_rightcount; i++) 
	{
		reslist_dynode_fit[i - (maxpositiony0 - fit_leftcount)] = reslist_dynode1[i];
		x[i - (maxpositiony0 - fit_leftcount)] = i;
	}

	maxpositiony0 = max_element(reslist_dynode_fit, reslist_dynode_fit + fit_leftcount + fit_rightcount) - reslist_dynode_fit;
	double maxvaluey0 = *max_element(reslist_dynode_fit, reslist_dynode_fit + fit_leftcount + fit_rightcount);
	double max_0 = Ge_amp_poln_fitrange(x, reslist_dynode_fit, maxpositiony0, maxvaluey0, 4);
	if (max_0 < lower_value && max_0 > super_value) { return false;}
	free(reslist_dynode_fit);
	free(x);
	free(reslist_dynode1);*/
	return true;

}

bool AMOC_tool::dynode_peak_judge_stop(double* reslist_dynode, double lower_value, double super_value, int SCANCOUNT)
{
	double* reslist_dynode1 = (double*)calloc(leftcount + rightcount, sizeof(double));
	double baseline = (double)accumulate(reslist_dynode + 0, reslist_dynode + 50, 0.0) / 50;
	for (int i = stop_initial_position - leftcount; i != stop_initial_position + rightcount; i++) {
		reslist_dynode1[i - (stop_initial_position - leftcount)] = reslist_dynode[i]- baseline;
	}
	double maxValuey0 = *max_element(reslist_dynode1, reslist_dynode1 + leftcount + rightcount);
	
	if (maxValuey0 < stop_lower || maxValuey0 > stop_upper) { return false; }

/*
	int maxPositiony0 = max_element(reslist_dynode1, reslist_dynode1 + leftcount + rightcount) - reslist_dynode1;
	if (maxPositiony0 - fit_leftcount < 0 || maxPositiony0 + fit_rightcount > leftcount + rightcount) { return false; }

	double* reslist_dynode_fit = (double*)calloc(fit_leftcount + fit_rightcount, sizeof(double));
	double* x = (double*)calloc(fit_leftcount + fit_rightcount, sizeof(double));
	for (int i = maxPositiony0 - fit_leftcount; i != maxPositiony0 + fit_rightcount; i++) {
		reslist_dynode_fit[i - (maxPositiony0 - fit_leftcount)] = reslist_dynode1[i];
		x[i - (maxPositiony0 - fit_leftcount)] = i;
	}
	maxPositiony0 = max_element(reslist_dynode_fit, reslist_dynode_fit + fit_leftcount + fit_rightcount) - reslist_dynode_fit;
	maxValuey0 = *max_element(reslist_dynode_fit, reslist_dynode_fit + fit_leftcount + fit_rightcount);
	double max_0 = Ge_amp_poln_fitrange(x, reslist_dynode_fit, maxPositiony0, maxValuey0, 4);
	if (max_0 < lower_value && max_0 > super_value) { return false; }

	free(reslist_dynode_fit);
	free(x);
	free(reslist_dynode1);*/
	return true;
}


double AMOC_tool::TAC_amplitude(double* TAC, int start_point, int end_point, int SCANCOUNT)//����AMOCʱ����AMOC_fiexd��AMOC_shape_filter����ʹ��
{
	double  TAC_removebasline[5000] = {0};
	for (int i = start_point; i != end_point; i++)
	{
		TAC_removebasline[i] = TAC[i] - base_line_TAC;
	}

	double lifetimedata = (double)accumulate(TAC_removebasline + start_point, TAC_removebasline + end_point, 0.0) / (end_point- start_point);
	return lifetimedata;
}

double AMOC_tool::TAC_amplitude_get(double* TAC, int SCANCOUNT,bool* judge)//������������ʱ��ʹ��
{
	//TAC�����ж��Ƿ���
	double lifetimedata = 0;
	int start_point = 0,end_point =0,  half_rightch = 0;
	start_point = end_point = 0;
	double maxValuey0 = *max_element(TAC, TAC + SCANCOUNT);
	TAC_max = maxValuey0;

	if (maxValuey0 < -31000 || maxValuey0 >= 32767) { *judge = false; return 0; }
	base_line_TAC = accumulate(TAC + 0, TAC + 50, 0.0) / 50; // ���50�����������ƽ��ֵ��Ϊ����



	int maxPositiony0 = max_element(TAC, TAC + SCANCOUNT) - TAC;
	double half_valueright = (TAC_max + base_line_TAC) / 2;
	double half_valueright_diff = 32768;

	if (maxPositiony0 >= SCANCOUNT - 20 || maxPositiony0 < 50)
	{
		//cout << "TAC�������ֵλ����ĩβ���������������presamples,Nsmaples: " << endl;
		//cout << "0: " << maxPositiony0 << "  " << SCANCOUNT - 20 << endl;
		*judge = false; return 0;
	}
	for (int i = SCANCOUNT - 20; i != maxPositiony0; i--)
	{
		if (abs(TAC[i] - half_valueright) < half_valueright_diff)
		{
			half_valueright_diff = abs(TAC[i] - half_valueright);
			half_rightch = i;
		}
	}

	for (int i = half_rightch; i != maxPositiony0-5; i--)
	{
		if (TAC[i] > TAC[i - 1])
		{
			end_point = i - 1;
		    break; 
		}
	}

	for (int i = 50; i != end_point; i++)
	{
		if (TAC[i] + TAC_flatop_std > TAC_max)
		{
			start_point = i;
			break;
		}
	}

	//cout << "end_point: " << end_point << "  start_point: " << start_point << "  half_rightch: " << half_rightch << "  judge: " << *judge << endl;
	if (end_point - start_point < 20 || end_point - start_point > 120) { *judge = false; return 0; }

	lifetimedata = TAC_amplitude(TAC, start_point, end_point, SCANCOUNT);

   //cout << "end_point: " <<end_point << "  start_point: " << start_point << "  half_rightch: " << half_rightch <<"  judge: "<< *judge << endl;
	/*double lifetimedata1 = TAC_amplitude(TAC_removebasline, start_point, end_point);
	double lifetimedata2 = TAC_amplitude(TAC, start_point, end_point);
	cout << lifetimedata1 << "  " << lifetimedata2- base_line_TAC << endl;*/

	return lifetimedata;

	
}



bool AMOC_tool::AMOC_fiexd(double* TAC, double* HPGE, int* start_point, int* end_point,int leftcount,int rightcount,int SCANCOUNT )
{


	bool judge = true;//��ʼ��Ϊ�棬Ĭ�ϸô��¼�����ɱ���¼

	double maxValuey0 = *max_element(TAC, TAC + SCANCOUNT);
	TAC_max = maxValuey0;
	double maxValuey1 = *max_element(HPGE, HPGE + SCANCOUNT);

	amp_max=maxValuey1;
	int maxPositiony0 = max_element(TAC, TAC + SCANCOUNT) - TAC;

	int maxPositiony1 = max_element(HPGE, HPGE + SCANCOUNT) - HPGE;
	max_ch_HPGe= maxPositiony1;
	
    if (maxPositiony1 <= SCANCOUNT- rightcount && maxPositiony1 > leftcount && TAC_max < 32767 && amp_max < 32767)
//
//    if (max_ch_HPGe > leftcount && (SCANCOUNT - max_ch_HPGe) > rightcount)
	{
		//���ɳ��ֶ����λ
		//base_line_HPGe = accumulate(HPGE + SCANCOUNT - 51, HPGE + SCANCOUNT - 1, 0) / 50; // 250:300����ƽ��ֵ��Ϊ����
		base_line_HPGe = accumulate(HPGE , HPGE + 50, 0) / 50; // 250:300����ƽ��ֵ��Ϊ����
		int count_max = 0;
		int standard_count = 15;
		for (int i = standard_count; i != SCANCOUNT - standard_count; i++)
		{
			if (HPGE[i] < base_line_HPGe + 500) { continue; }

			int count_judge_peak = 0;

			for (int j1 = 0; j1 != standard_count; j1++)
			{
				if (HPGE[i] > HPGE[i + j1 - standard_count]) { count_judge_peak += 1; }
			}
			if (count_judge_peak != standard_count) { continue; }

			for (int j2 = 0; j2 != standard_count; j2++)
			{
				if (HPGE[i] >= HPGE[i + j2 + 1]) { count_judge_peak += 1; }
			}
			if (count_judge_peak == standard_count * 2)
			{
				count_max += 1;
			}
			if (count_max == 2) { break; }
		}
		if (count_max != 1) { judge = false; return judge; }
		
	////HPGE�����ж��Ƿ�����β�����ɰ�͹��ƽ

		//int judge_count_peak_tail = 0;

		//for (int kk = SCANCOUNT-50; kk != SCANCOUNT; kk++)
		//{
		//	if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)
		//	{
		//		judge_count_peak_tail = judge_count_peak_tail + 1;
		//	};
		//	//cout << "here" <<"  "<< HPGE[kk] <<"  " << baseline << "  " << judge_count_peak_tail << endl;
		//	if (judge_count_peak_tail > HPGejudge_num) {

		//		judge = false; return judge;
		//	}//������false����ô��¼�������
		//}

		//HPGE�����ж��Ƿ�����ͷ�����ɰ�͹��ƽ
		int judge_count_peak_head = 0;

		for (int kk = 0; kk != 50; kk++)
		{
			if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)
			{
				judge_count_peak_head = judge_count_peak_head + 1;
			};
		//	cout << "here" <<"  "<< HPGE[kk] <<"  " << base_line_HPGe << "  " << judge_count_peak_head << endl;
			if (judge_count_peak_head > HPGejudge_num) 
			{

				judge = false; return judge;
			}//������false����ô��¼�������
		}
		//cout << judge_count_peak_head << endl;
		
		//TAC�����ж��Ƿ���
		int half_rightch = 0;
		base_line_TAC = accumulate(TAC + 0, TAC + 50, 0.0) / 50; // ���50�����������ƽ��ֵ��Ϊ����
		double half_valueright = (TAC_max + base_line_TAC) / 2;
		double half_valueright_diff = 32768;

		if(maxPositiony0 >= SCANCOUNT - 20 || maxPositiony0 < 50)
		{
			//cout << "TAC�������ֵλ����ĩβ���������������presamples,Nsmaples: " << endl;
		 //   cout <<"0: " << maxPositiony0 << "  " << SCANCOUNT - 20 << endl;
			judge = false; return judge;
		}


		for (int i = SCANCOUNT - 20; i != maxPositiony0; i--)
		{
			if (abs(TAC[i] - half_valueright) < half_valueright_diff)
			{
				half_valueright_diff = abs(TAC[i] - half_valueright);
				half_rightch = i;
			}
		}

	   //cout << "1: " << maxPositiony0<<"  "<< half_rightch << endl;
		for (int i = half_rightch; i != maxPositiony0-5; i--)
		{
			if (TAC[i] > TAC[i - 1])
			{
				*end_point = i - 1;
				break;
			}
		}

		for (int i = 50; i != *end_point; i++)
		{
			if (TAC[i] + TAC_flatop_std > TAC_max)
			{
				*start_point = i;
				break;
			}
		}
		//cout <<"2: " << *end_point << "  " << *start_point << endl;
		if (*end_point - *start_point < 20 || *end_point - *start_point > 120) { judge = false; return judge; }

		judge = true;
	}
	else 
    {
		judge = false; return judge;
	}//������false����ô��¼�������

	return judge;//������false����ô��¼���̭��

}




bool AMOC_tool::AMOC_shape_filter(double* lower0,double* upper0,double* TAC, double* HPGE, int* start_point, int* end_point, int leftcount, int rightcount,int SCANCOUNT)
{

	int pulse_wide = leftcount + rightcount;
	bool judge = true;//��ʼ��Ϊ�棬Ĭ�ϸô��¼�����ɱ���¼

	double maxValuey0 = *max_element(TAC, TAC + SCANCOUNT);
	TAC_max = maxValuey0;
	double maxValuey1 = *max_element(HPGE, HPGE + SCANCOUNT);

	amp_max = maxValuey1;
	int maxPositiony0 = max_element(TAC, TAC + SCANCOUNT) - TAC;

	int maxPositiony1 = max_element(HPGE, HPGE + SCANCOUNT) - HPGE;
	max_ch_HPGe = maxPositiony1;

	if (maxPositiony1 <= SCANCOUNT - rightcount && maxPositiony1 > leftcount && TAC_max < 32767 && amp_max < 32767 && TAC_max>-31000)
		//
		//    if (max_ch_HPGe > leftcount && (SCANCOUNT - max_ch_HPGe) > rightcount)
	{
		//���ɳ��ֶ����λ
		//base_line_HPGe = accumulate(HPGE + SCANCOUNT - 51, HPGE + SCANCOUNT - 1, 0) / 50; // 250:300����ƽ��ֵ��Ϊ����
		base_line_HPGe = accumulate(HPGE, HPGE + 50, 0) / 50; // 250:300����ƽ��ֵ��Ϊ����
		int count_max = 0;
		int standard_count = 5;
		for (int i = standard_count; i != SCANCOUNT - standard_count; i++)
		{
			if (HPGE[i] < base_line_HPGe + 500) { continue; }

			int count_judge_peak = 0;

			for (int j1 = 0; j1 != standard_count; j1++)
			{
				if (HPGE[i] > HPGE[i + j1 - standard_count]) { count_judge_peak += 1; }
			}
			if (count_judge_peak != standard_count) { continue; }

			for (int j2 = 0; j2 != standard_count; j2++)
			{
				if (HPGE[i] >= HPGE[i + j2 + 1]) { count_judge_peak += 1; }
			}
			if (count_judge_peak == standard_count * 2)
			{
				count_max += 1;
			}
			if (count_max == 2) { break; }
		}
		if (count_max != 1) { judge = false; return judge; }

		//////HPGE�����ж��Ƿ�����β�����ɰ�͹��ƽ

		//	int judge_count_peak_tail = 0;

		//	for (int kk = SCANCOUNT-50; kk != SCANCOUNT; kk++)
		//	{
		//		if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)
		//		{
		//			judge_count_peak_tail = judge_count_peak_tail + 1;
		//		};
		//		//cout << "here" <<"  "<< HPGE[kk] <<"  " << baseline << "  " << judge_count_peak_tail << endl;
		//		if (judge_count_peak_tail > HPGejudge_num) {

		//			judge = false; return judge;
		//		}//������false����ô��¼�������
		//	}

			//HPGE�����ж��Ƿ�����ͷ�����ɰ�͹��ƽ
		int judge_count_peak_head = 0;

		for (int kk = 0; kk != 50; kk++)
		{
			if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)
			{
				judge_count_peak_head = judge_count_peak_head + 1;
			};
			///cout << "here" <<"  "<< HPGE[kk] <<"  " << base_line_HPGe << "  " << judge_count_peak_head << endl;
			if (judge_count_peak_head > HPGejudge_num) {

				judge = false; return judge;
			}//������false����ô��¼�������
		}
		//cout << judge_count_peak_head << "    " << judge_count_peak_tail << endl;


		//��״�����
		double* new_HPGE = (double*)calloc(pulse_wide, sizeof(double));

		double multiple = (amp_max - base_line_HPGe) / 1000;
		for (int i = 0; i != pulse_wide; ++i)
		{
			new_HPGE[i] = (*(HPGE + max_ch_HPGe - leftcount + i) - base_line_HPGe) / multiple;
		}


		int judge_item = 0;
		for (int j = 0; j != pulse_wide; ++j)
		{
			//            cout<<new_HPGE[j]<<"  "<< lower0[j]<<"  "<< upper0[j]<<endl;
			if (new_HPGE[j] >= lower0[j] && new_HPGE[j] <= upper0[j])//�� *(upper0 + i��
			{
				judge_item = judge_item + 1;
			}
		}

		//cout<<judge_item<<endl;
		if (judge_item<int(pulse_wide * 0.95))//����������״������ж��������򷵻�false
		{
			//            cout<<judge_item<<endl;
			judge = false; return judge;
		}
		free(new_HPGE);

		//TAC�����ж��Ƿ���
		int half_rightch = 0;
		base_line_TAC = accumulate(TAC + 0, TAC + 50, 0.0) / 50; // ���50�����������ƽ��ֵ��Ϊ����
		double half_valueright = (TAC_max + base_line_TAC) / 2;
		double half_valueright_diff = 32768;

		if (maxPositiony0 >= SCANCOUNT - 20 || maxPositiony0 < 50)
		{
			cout << "TAC�������ֵλ����ĩβ���������������presamples,Nsmaples: " << endl;
			cout << "0: " << maxPositiony0 << "  " << SCANCOUNT - 50 << endl;
			judge = false; return judge;
		}

		for (int i = SCANCOUNT - 20; i != maxPositiony0; i--)
		{
			if (abs(TAC[i] - half_valueright) < half_valueright_diff)
			{
				half_valueright_diff = abs(TAC[i] - half_valueright);
				half_rightch = i;
			}
		}

		//cout << "1: " << maxPositiony0<<"  "<< half_rightch << endl;
		for (int i = half_rightch; i != maxPositiony0-5; i--)
		{
			if (TAC[i] > TAC[i - 1])
			{
				*end_point = i - 1;
				break;
			}
		}

		for (int i = 50; i != *end_point; i++)
		{
			if (TAC[i] + TAC_flatop_std > TAC_max)
			{
				*start_point = i;
				break;
			}
		}
		//cout <<"2: " << *end_point << "  " << *start_point << endl;
		if (*end_point - *start_point < 50 || *end_point - *start_point > 350) { judge = false; return judge; }

		judge = true;
	}
	else
	{
		judge = false; return judge;
	}//������false����ô��¼�������

	return judge;//������false����ô��¼���̭��

}


bool AMOC_tool::HPGE_shape_filter(double* lower0,double* upper0,double* HPGE,int leftcount, int rightcount,int SCANCOUNT)
{
	bool judge = true;//��ʼ��Ϊ�棬Ĭ�ϸô��¼�����ɱ���¼
	int pulse_wide=leftcount+rightcount;
	double maxValuey1 = *max_element(HPGE, HPGE + SCANCOUNT);
	amp_max=maxValuey1;
	int maxPositiony1 = max_element(HPGE, HPGE + SCANCOUNT) - HPGE;
	max_ch_HPGe= maxPositiony1;
	base_line_HPGe = accumulate(HPGE, HPGE + 50, 0.0) / 50; // ���50�����������ƽ��ֵ��Ϊ����
	
	double sum_std = 0;
	for (int i = 0; i != 50; i++) {
		sum_std = pow(HPGE[i]- base_line_HPGe, 2) + sum_std;
	}
	base_line_HPGe_std = pow(sum_std / 50, 0.5);
	//if (base_line_HPGe_std > base_line_HPGe_std_thouread) { judge = false; return judge; }

    if (maxPositiony1 <= SCANCOUNT - rightcount - 50 && maxPositiony1 > leftcount + 50 && maxValuey1 < 32767)
//
//    if (max_ch_HPGe > num_width && (SCANCOUNT - max_ch_HPGe) > num_width)
    {
		//���ɳ��ֶ����λ
		int count_max=0;
		int standard_count = 5;
		for (int i = standard_count; i != SCANCOUNT - standard_count; i++)
		{
			if (HPGE[i] < base_line_HPGe + 500){continue;}
			
		    int count_judge_peak=0;

		    for (int j1=0;j1!=standard_count;j1++)
		    {
		        if(HPGE[i]>HPGE[i+j1-standard_count]) {count_judge_peak+=1;}
		    }
		    if (count_judge_peak!=standard_count){continue;}

		    for (int j2=0;j2!=standard_count;j2++)
		    {
		        if(HPGE[i]>=HPGE[i+j2+1]) {count_judge_peak+=1;}
		    }
		    if (count_judge_peak==standard_count*2)
		    {
		        count_max+=1;
		    }
		    if (count_max==2){break;}


		}
		//cout<<"count_max: "<<count_max<<endl;
		if(count_max!=1){judge = false; return judge;}



//        cout<<max_ch_HPGe<<"  "<<amp_max<<endl;
//		HPGE�����ж��Ƿ�����β�����ɰ�͹��ƽ
		int judge_count_peak_tail = 0;

		for (int kk = SCANCOUNT-50; kk != SCANCOUNT; kk++)
		{
			if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)
			{
				judge_count_peak_tail = judge_count_peak_tail + 1;
			};
			/*cout << "here" <<"  "<< HPGE[kk] <<"  " << base_line_HPGe << "  " << judge_count_peak_tail << endl;*/
			if (judge_count_peak_tail > HPGejudge_num) {
               // cout<<"judge_count_peak_tail is not pass!!!"<<endl;
				judge = false; return judge;
			}//������false����ô��¼�������
		}

		////HPGE�����ж��Ƿ�����ͷ�����ɰ�͹��ƽ
		int judge_count_peak_head = 0;
		for (int kk = 0; kk != 50; kk++)
		{
			if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)
			{
				judge_count_peak_head = judge_count_peak_head + 1;
			};
			//cout << "here" <<"  "<< HPGE[kk] <<"  " << baseline << "  " << judge_count_peak_head << endl;
			if (judge_count_peak_head > HPGejudge_num) {
				//cout << "judge_count_peak_head is not pass!!!" << endl;
				judge = false; return judge;
			}//������false����ô��¼�������
		}

		double *new_HPGE = (double*)calloc(pulse_wide , sizeof(double));
        double multiple = (amp_max-base_line_HPGe)/ 1000;
        for (int i=0;i!=pulse_wide;++i)
        {
            new_HPGE[i]=(*(HPGE+max_ch_HPGe-leftcount+i)-base_line_HPGe)/multiple;
        }


        int judge_item = 0;
        for(int j=0;j!=pulse_wide;++j)
        {
//            cout<<new_HPGE[j]<<"  "<< lower0[j]<<"  "<< upper0[j]<<endl;
            if(new_HPGE[j]>=lower0[j] && new_HPGE[j]<=upper0[j])//�� *(upper0 + i��
                {
                judge_item=judge_item+1;
            }
        }
		free(new_HPGE);
		//cout << "jjudge_item: " << judge_item << endl;
        if (judge_item<int(pulse_wide * 0.98))//����������״������ж��������򷵻�false
            {

           //cout<<"jjudge_item is not pass: "<<judge_item<<endl;
            judge = false; return judge;
        }

////////////////////////////////////////////////////////////////////////////////////////

	}
	else {
//        cout<<"first step is not pass"<<endl;
		judge = false; return judge;
	}//������false����ô��¼�������

    return judge;//������false����ô��¼���̭��

}


bool AMOC_tool::HPGE_fiexd(double* HPGE ,int leftcount,int rightcount, int SCANCOUNT)
{

	bool judge = true;//��ʼ��Ϊ�棬Ĭ�ϸô��¼�����ɱ���¼

	double maxValuey1 = *max_element(HPGE, HPGE + SCANCOUNT);
	amp_max=maxValuey1;

	int maxPositiony1 = max_element(HPGE, HPGE + SCANCOUNT) - HPGE;
	max_ch_HPGe= maxPositiony1;
	base_line_HPGe = accumulate(HPGE, HPGE + 50, 0.0) / 50; // ���50��������ƽ��ֵ��Ϊ����
	double base_line_HPGe_post = accumulate(HPGE + SCANCOUNT -50 , HPGE + SCANCOUNT, 0.0) / 50; // ���50��������ƽ��ֵ��Ϊ����
	double sum_std = 0;
	for (int i = 0; i != 50; i++) {
		sum_std = pow(HPGE[i] - base_line_HPGe, 2) + sum_std;
	}
	base_line_HPGe_std = pow(sum_std / 50, 0.5);
	//if (base_line_HPGe_std > base_line_HPGe_std_thouread) { judge = false; return judge; }

	if (maxPositiony1 < SCANCOUNT - num_width && maxPositiony1 > num_width && maxValuey1 < 32767)
//
//    if (max_ch_HPGe > leftcount && (SCANCOUNT - max_ch_HPGe) > rightcount)
	{
	//	//���ɳ��ֶ����λ
		int count_max = 0;
		int standard_count = 15;
		for (int i = standard_count; i != SCANCOUNT - standard_count; i++)
		{
			if (HPGE[i] < base_line_HPGe + 500) { continue; }

			int count_judge_peak = 0;

			for (int j1 = 0; j1 != standard_count; j1++)
			{
				if (HPGE[i] > HPGE[i + j1 - standard_count]) { count_judge_peak += 1; }
			}
			if (count_judge_peak != standard_count) { continue; }

			for (int j2 = 0; j2 != standard_count; j2++)
			{
				if (HPGE[i] >= HPGE[i + j2 + 1]) { count_judge_peak += 1; }
			}
			if (count_judge_peak == standard_count * 2)
			{
				count_max += 1;
			}
			if (count_max == 2) { break; }


		}
		if (count_max != 1) { judge = false; return judge; }

		//HPGE�����ж��Ƿ�����β�����ɰ�͹��ƽ

		int judge_count_peak_tail = 0;

		for (int kk = SCANCOUNT-50; kk != SCANCOUNT; kk++)
		{
			if (fabs(HPGE[kk] - base_line_HPGe_post) > delta_HPGe)//�ò�����������߶�������
			{
				judge_count_peak_tail = judge_count_peak_tail + 1;
			};
			//cout << "here tail" <<"  "<< HPGE[kk] <<"  " << base_line_HPGe << "  " << judge_count_peak_tail << endl;
			if (judge_count_peak_tail > HPGejudge_num) {

				judge = false; return judge;
			}//������false����ô��¼�������

      
		}

		////HPGE�����ж��Ƿ�����ͷ�����ɰ�͹��ƽ
		int judge_count_peak_head = 0;

		for (int kk = 0; kk != 50; kk++)
		{
			if (fabs(HPGE[kk] - base_line_HPGe) > delta_HPGe)//�ò�����������߶�������
			{
				judge_count_peak_head = judge_count_peak_head + 1;
			};
			//cout << "here head" <<"  "<< HPGE[kk] <<"  " << base_line_HPGe << "  " << judge_count_peak_head << endl;
			if (judge_count_peak_head > HPGejudge_num) {

				judge = false; return judge;
			}//������false����ô��¼�������
		}
		//cout << judge_count_peak_tail << "    " << judge_count_peak_head << endl;
    }
	else { judge = false; return judge; }
    return judge;//������false����ô��¼���̭��
}


bool AMOC_tool::test() {
	cout <<  "here"  << endl;
	return 0;
}
int AMOC_tool::test2(double* HPGE, int leftcount, int rightcount,int SCANCOUNT)
{
    return 0;
}
