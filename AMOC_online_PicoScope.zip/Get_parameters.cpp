#include "Get_parameters.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

Get_parameters::Get_parameters() {

}

Get_parameters::~Get_parameters() {

}

void Get_parameters::read_in(string filename, Param_pals* par) {
	fstream file_in(filename, ios::in);
	string line;
	while (getline(file_in, line)) {
		istringstream sin(line);
		string command;
		sin >> command;
		if (command == "CHA") {
			int a0, a1;
			double offset;
			sin >> a0 >> a1 >> offset;
			if (a0 == 0) par->cha = FALSE;
			else par->cha = TRUE;
			par->cha_r = a1;
			par->cha_offset = offset;
		}
		else if (command == "CHB") {
			int a0, a1;
			double offset;
			sin >> a0 >> a1 >> offset;
			if (a0 == 0) par->chb = FALSE;
			else par->chb = TRUE;
			par->chb_r = a1;
			par->chb_offset = offset;
		}
		else if (command == "CHC") {
			int a0, a1;
			double offset;
			sin >> a0 >> a1 >> offset;
			if (a0 == 0) par->chc = FALSE;
			else par->chc = TRUE;
			par->chc_r = a1;
			par->chc_offset = offset;
		}
		else if (command == "CHD") {
			int a0, a1;
			double offset;
			sin >> a0 >> a1 >> offset;
			if (a0 == 0) par->chd = FALSE;
			else par->chd = TRUE;
			par->chd_r = a1;
			par->chd_offset = offset;
		}
		else if (command == "Triset") {
			sin >> par->tri_mode >> par->cha_tr >> par->chb_tr >> par->chc_tr >> par->chd_tr;
		}
		else if (command == "CHA_thr") {
			sin >> par->cha_thr[0] >> par->cha_thr[1] >> par->cha_thr[2] >> par->cha_thr[3] >> par->cha_thr[4];
		}
		else if (command == "CHB_thr") {
			sin >> par->chb_thr[0] >> par->chb_thr[1] >> par->chb_thr[2] >> par->chb_thr[3] >> par->chb_thr[4];
		}
		else if (command == "CHC_thr") {
			sin >> par->chc_thr[0] >> par->chc_thr[1] >> par->chc_thr[2] >> par->chc_thr[3] >> par->chc_thr[4];
		}
		else if (command == "CHD_thr") {
			sin >> par->chd_thr[0] >> par->chd_thr[1] >> par->chd_thr[2] >> par->chd_thr[3] >> par->chd_thr[4];
		}
		else if (command == "ANTI_thr") {
			sin >> par->anti_thr;
		}
		else if (command == "GETDATA") {
			sin >> par->get_d;
		}
		else if (command == "MEAS") {
			sin >> par->meas_mode;
		}
		else if (command == "OUTFILE") {
			sin >> par->outfile_name;
		}
		else if (command == "FRAC") {
			sin >> par->fraction;
		}
		else if (command == "T_COUNTS") {
			sin >> par->total_count;
		}
		else if (command == "SAMPLES") {
			sin >> par->n_presamples >> par->n_samples;
		}
		else if (command == "TIMEBASE") {
			sin >> par->timebase0;
		}
		else if (command == "CAPTURE") {
			sin >> par->n_captures;
		}
		else if (command == "E_N") {
			sin >> par->n_epre >> par->n_etotal;
		}

	}
}
void Get_parameters::set_para(Param_pals* par) {
	//ͨ������ command ͨ����bool�����̣�ƫ����
	par->cha = TRUE;
	par->chb = FALSE;
	par->chc = TRUE;
	par->chd = FALSE;
	par->cha_r = 4;
	par->chb_r = 4;
	par->chc_r = 4;
	par->chd_r = 4;
	par->cha_offset = 1.8;
	par->chb_offset = 1.8;
	par->chc_offset = 1.8;
	par->chd_offset = 1.8;
	//����ģʽ
	par->tri_mode = "CHA_T";
	par->cha_tr = 27000;
	par->chb_tr = 27000;
	par->chc_tr = 27000;
	par->chd_tr = 27000;
	//����ģʽ
	par->meas_mode = "E_MODE";
	par->e_ch = "cha";
	//����ļ�
	par->outfile_name = "out/out.txt";
	//������ֵ
	double ktr[5] = { -23000,-1000,6500,19500,25000 };
	for (int i = 0; i < 5; i++) {
		par->cha_thr[i] = ktr[i];
		par->chb_thr[i] = ktr[i];
		par->chc_thr[i] = ktr[i];
		par->chd_thr[i] = ktr[i];
	}
	//��������ֵ
	par->anti_thr = 27500;
	//���ݲɼ�
	par->get_d = "AC_MODE";
	//frac
	par->fraction = 0.15;
	//�ܼ���
	par->total_count = 50000;
	//samples
	par->n_presamples = 200;
	par->n_samples = 800;
	//timebase
	par->timebase0 = 1;
	//captures
	par->n_captures = 500;

	par->n_epre = 2000;
	par->n_etotal = 6000;

}

