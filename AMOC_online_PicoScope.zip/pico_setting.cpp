#pragma once
/* Headers for Windows */

#ifdef _WIN32
#include "windows.h"
#include <conio.h>
#include "ps5000aApi.h"
#include "AMOC_tool.h"
#include "pico_setting.h"
#include <cmath>
#include <iostream>
#include <fstream>
#include <numeric>
#include<algorithm>
#include <iomanip>
#include <cstdlib>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <ctime>
using namespace std;
#else
#include <sys/types.h>
#include <string.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <libps5000a-1.1/ps5000aApi.h>
#ifndef PICO_STATUS
#include <libps5000a-1.1/PicoStatus.h>
#endif

#define Sleep(a) usleep(1000*a)
#define scanf_s scanf
#define fscanf_s fscanf
#define memcpy_s(a,b,c,d) memcpy(a,c,d)

typedef enum enBOOL { FALSE, TRUE } BOOL;

/* A function to detect a keyboard press on Linux */
int32_t _getch()
{
	struct termios oldt, newt;
	int32_t ch;
	int32_t bytesWaiting;
	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	setbuf(stdin, NULL);
	do {
		ioctl(STDIN_FILENO, FIONREAD, &bytesWaiting);
		if (bytesWaiting)
			getchar();
	} while (bytesWaiting);

	ch = getchar();

	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	return ch;
}

int32_t _kbhit()
{
	struct termios oldt, newt;
	int32_t bytesWaiting;
	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	setbuf(stdin, NULL);
	ioctl(STDIN_FILENO, FIONREAD, &bytesWaiting);

	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	return bytesWaiting;
}

int32_t fopen_s(FILE** a, const int8_t* b, const int8_t* c)
{
	FILE* fp = fopen(b, c);
	*a = fp;
	return (fp > 0) ? 0 : -1;
}

/* A function to get a single character on Linux */
#define max(a,b) ((a) > (b) ? a : b)
#define min(a,b) ((a) < (b) ? a : b)
#endif

extern int32_t cycles = 0;

#define BUFFER_SIZE 	1024

#define QUAD_SCOPE		4
#define DUAL_SCOPE		2

#define MAX_PICO_DEVICES 64
#define TIMED_LOOP_STEP 500
uint16_t inputRanges_dis[PS5000A_MAX_RANGES] = {
												10,
												20,
												50,
												100,
												200,
												500,
												1000,
												2000,
												5000,
												10000,
												20000,
												50000 };
PICO_STATUS pico_ctrl::OpenDevice(UNIT_5000* unit, int8_t* serial)
{
	PICO_STATUS status;
	unit->resolution = PS5000A_DR_8BIT;

	if (serial == NULL)
	{
		status = ps5000aOpenUnit(&unit->handle, NULL, unit->resolution);
	}
	else
	{
		status = ps5000aOpenUnit(&unit->handle, serial, unit->resolution);
	}

	unit->openStatus = (int16_t)status;
	unit->complete = 1;

	return status;
}


PICO_STATUS pico_ctrl::handleDevice(UNIT_5000* unit)
{
	int cycles = 0;
	int16_t value = 0;
	int32_t i;
	//struct tPwq pulseWidth;
	PICO_STATUS status;

	printf("Handle: %d\n", unit->handle);

	if (unit->openStatus != PICO_OK)
	{
		printf("Unable to open device\n");
		printf("Error code : 0x%08x\n", (uint32_t)unit->openStatus);
		while (!_kbhit());
		exit(99); // exit program
	}

	printf("Device opened successfully, cycle %d\n\n", ++cycles);

	// Setup device info - unless it's set already
	if (unit->model == MODEL_NONE)
	{
		set_info(unit);
	}

	// Turn off any digital ports (MSO models only)
	if (unit->digitalPortCount > 0)
	{
		printf("Turning off digital ports.");

		for (i = 0; i < unit->digitalPortCount; i++)
		{
			status = ps5000aSetDigitalPort(unit->handle, (PS5000A_CHANNEL)(i + PS5000A_DIGITAL_PORT0), 0, 0);
		}
	}

	//timebase_0 = 1;

	ps5000aMaximumValue(unit->handle, &value);
	unit->maxADCValue = value;
	cout << "maxADCValue: " << unit->maxADCValue << endl;
	status = ps5000aCurrentPowerSource(unit->handle);
	//memset(&pulseWidth, 0, sizeof(struct tPwq));

	//setDefaults(unit);

	/* Trigger disabled	*/
	status = ps5000aSetSimpleTrigger(unit->handle, 0, PS5000A_CHANNEL_A, 0, PS5000A_RISING, 0, 0);
	//PICO_STATUS status;
	PICO_STATUS powerStatus;


	status = ps5000aSetEts(unit->handle, PS5000A_ETS_OFF, 0, 0, NULL);					// Turn off hasHardwareETS
	//printf(status ? "setDefaults:ps5000aSetEts------ 0x%08lx \n" : "", status);

	powerStatus = ps5000aCurrentPowerSource(unit->handle);

	for (int i = 0; i < unit->channelCount; i++) // reset channels to most recent settings
	{
		if (i >= DUAL_SCOPE && powerStatus == PICO_POWER_SUPPLY_NOT_CONNECTED)
		{
			// No need to set the channels C and D if Quad channel scope and power not enabled.
		}
		else
		{
			status = ps5000aSetChannel(unit->handle, (PS5000A_CHANNEL)(PS5000A_CHANNEL_A + i),
				unit->channelSettings[PS5000A_CHANNEL_A + i].enabled,
				(PS5000A_COUPLING)unit->channelSettings[PS5000A_CHANNEL_A + i].DCcoupled,
				(PS5000A_RANGE)unit->channelSettings[PS5000A_CHANNEL_A + i].range,
				unit->channelSettings[PS5000A_CHANNEL_A + i].analogueOffset);

			//printf(status ? "SetDefaults:ps5000aSetChannel------ 0x%08lx \n" : "", status);

		}
	}
	return unit->openStatus;
}
///***************************************************************************************************/
void pico_ctrl::set_info(UNIT_5000* unit)
{
	int8_t description[11][25] = { "Driver Version",
		"USB Version",
		"Hardware Version",
		"Variant Info",
		"Serial",
		"Cal Date",
		"Kernel Version",
		"Digital HW Version",
		"Analogue HW Version",
		"Firmware 1",
		"Firmware 2" };

	int16_t i = 0;
	int16_t requiredSize = 0;
	int8_t line[80];
	int32_t variant;
	PICO_STATUS status = PICO_OK;

	// Variables used for arbitrary waveform parameters
	int16_t			minArbitraryWaveformValue = 0;
	int16_t			maxArbitraryWaveformValue = 0;
	uint32_t		minArbitraryWaveformSize = 0;
	uint32_t		maxArbitraryWaveformSize = 0;

	//Initialise default unit properties and change when required
	unit->sigGen = SIGGEN_FUNCTGEN;
	unit->firstRange = PS5000A_10MV;
	unit->lastRange = PS5000A_20V;
	unit->channelCount = DUAL_SCOPE;
	unit->awgBufferSize = MIN_SIG_GEN_BUFFER_SIZE;
	unit->digitalPortCount = 0;

	if (unit->handle)
	{
		printf("Device information:-\n\n");

		for (i = 0; i < 11; i++)
		{
			status = ps5000aGetUnitInfo(unit->handle, line, sizeof(line), &requiredSize, i);

			// info = 3 - PICO_VARIANT_INFO
			if (i == PICO_VARIANT_INFO)
			{
				//variant = atoi(line);
				memcpy(&(unit->modelString), line, sizeof(unit->modelString) == 5 ? 5 : sizeof(unit->modelString));

				unit->channelCount = (int16_t)line[1];
				unit->channelCount = unit->channelCount - 48; // Subtract ASCII 0 (48)

				// Determine if the device is an MSO
	/*			if (strstr(line, "MSO") != NULL)
				{
					unit->digitalPortCount = 2;
				}
				else
				{
					unit->digitalPortCount = 0;
				}*/
				//printf("if (i == PICO_VARIANT_INFO) : %d  %d  %d", line, unit->modelString, i, variant);

			}
			else if (i == PICO_BATCH_AND_SERIAL)	// info = 4 - PICO_BATCH_AND_SERIAL
			{
				memcpy(&(unit->serial), line, requiredSize);
			}

			printf("%s: %s\n", description[i], line);
		}

		printf("\n");

		// Set sig gen parameters
		// If device has Arbitrary Waveform Generator, find the maximum AWG buffer size
		status = ps5000aSigGenArbitraryMinMaxValues(unit->handle, &minArbitraryWaveformValue, &maxArbitraryWaveformValue, &minArbitraryWaveformSize, &maxArbitraryWaveformSize);
		unit->awgBufferSize = maxArbitraryWaveformSize;

		if (unit->awgBufferSize > 0)
		{
			unit->sigGen = SIGGEN_AWG;
		}
		else
		{
			unit->sigGen = SIGGEN_FUNCTGEN;
		}
	}
}
/****************************************************************************
* handleDevice
* Parameters
* - unit        pointer to the UNIT structure, where the handle will be stored
*
* Returns
* - PICO_STATUS to indicate success, or if an error occurred
***************************************************************************/
void closeDevice(UNIT_5000* UNIT_5000)
{
	ps5000aCloseUnit(UNIT_5000->handle);
}

void printResolution(PS5000A_DEVICE_RESOLUTION* resolution)
{
	switch (*resolution)
	{
	case PS5000A_DR_8BIT:

		printf("8 bits");
		break;

	case PS5000A_DR_12BIT:

		printf("12 bits");
		break;

	case PS5000A_DR_14BIT:

		printf("14 bits");
		break;

	case PS5000A_DR_15BIT:

		printf("15 bits");
		break;

	case PS5000A_DR_16BIT:

		printf("16 bits");
		break;

	default:

		break;
	}

	printf("\n");
}
void pico_ctrl::displaySettings(UNIT_5000* unit)
{
	int32_t ch;
	int32_t voltage;
	PICO_STATUS status = PICO_OK;
	PS5000A_DEVICE_RESOLUTION resolution = PS5000A_DR_8BIT;
	printf("***************************************************************************\n");
	printf("\nReadings will be scaled in %s\n", (scaleVoltages) ? ("millivolts") : ("ADC counts"));
	printf("\n");

	for (ch = 0; ch < unit->channelCount; ch++)
	{
		if (!(unit->channelSettings[ch].enabled))
		{
			printf("Channel %c Voltage Range = Off\n", 'A' + ch);
		}
		else
		{
			voltage = inputRanges_dis[unit->channelSettings[ch].range];
			printf("Channel %c Voltage Range = ", 'A' + ch);

			if (voltage < 1000)
			{
				printf("%dmV  ADC_value:%d\n", voltage, voltage * unit->maxADCValue/ inputRanges_dis[unit->channelSettings[ch].range]);
			}
			else
			{
				printf("%dV   ADC_value:%d\n", voltage / 1000, voltage * unit->maxADCValue/ inputRanges_dis[unit->channelSettings[ch].range]);
			}
		}
	}

	printf("\n");

	status = ps5000aGetDeviceResolution(unit->handle, &resolution);

	printf("Device Resolution: ");
	printResolution(&resolution);

}
pico_ctrl::pico_ctrl(int rsl) {
	status = PICO_OK;
	pico_timeInterval = 0.00f;
	nCaptures = 100000;
	timebase_0 = 2;
	nSamples = 400;
	npreSamples = 100;
	npostSamples = nSamples - npreSamples;
	segmentIndex = 0;
	switch (rsl)
	{
	case 0: {
		resolution_5000 = PS5000A_DR_8BIT;
		break;
	}
	case 1: {
		resolution_5000 = PS5000A_DR_12BIT;
		break;
	}
	case 2: {
		resolution_5000 = PS5000A_DR_14BIT;
		break;
	}
	case 3: {
		resolution_5000 = PS5000A_DR_15BIT;
		break;
	}
	case 4: {
		resolution_5000 = PS5000A_DR_16BIT;
		break;
	}
	
	default:break;
	}
}

/* ��������ֵ��channelSettings�ṹ�壬�������÷ֱ�����ʱ��*/
int pico_ctrl::channelSetting_in(int ch_i,bool q1,int r1,double offset) {
	allUnits[0].channelSettings[ch_i].DCcoupled = TRUE;
	allUnits[0].channelSettings[ch_i].enabled = q1;
	allUnits[0].channelSettings[ch_i].range = r1;
	allUnits[0].channelSettings[ch_i].analogueOffset = offset;
	return 0;
}

void pico_ctrl::set_samples(int nS, int npre) {
	nSamples = nS;
	npreSamples = npre;
	npostSamples = nSamples - npreSamples;
	cout << "npreSamples: " << npre << "   nSamples: " << nS << endl;

}
pico_ctrl::~pico_ctrl() {

}

int pico_ctrl::pico_find_and_setting() {

	int8_t ch;
	uint16_t devCount = 0, listIter = 0, openIter = 0;
	//device indexer -  64 chars - 64 is maximum number of picoscope devices handled by driver
	int8_t devChars[] =
		"1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz#";
	PICO_STATUS status = PICO_OK;

	printf("PicoScope 5000 Series (ps5000a) Driver Example Program\n");
	printf("\nEnumerating Units...\n");

	do
	{
		status = OpenDevice(&(allUnits[devCount]), NULL);

		if (status == PICO_OK || status == PICO_POWER_SUPPLY_NOT_CONNECTED
			|| status == PICO_USB3_0_DEVICE_NON_USB3_0_PORT)
		{
			allUnits[devCount++].openStatus = (int16_t)status;//��Ѱ�豸����Ӧ�豸�����ṹ��openStatusȫ������ΪPICO_OK
		}

	} while (status != PICO_NOT_FOUND);

	if (devCount == 0)
	{
		printf("Picoscope devices not found\n");
		return 1;
	}

	// if there is only one device, open and handle it here
	if (devCount == 1)
	{
		printf("Found one device, opening...\n\n");
		status = allUnits[0].openStatus;

		if (status == PICO_OK || status == PICO_POWER_SUPPLY_NOT_CONNECTED
			|| status == PICO_USB3_0_DEVICE_NON_USB3_0_PORT)
		{
			/*if (allUnits[0].openStatus == PICO_POWER_SUPPLY_NOT_CONNECTED || allUnits[0].openStatus == PICO_USB3_0_DEVICE_NON_USB3_0_PORT)
			{
				allUnits[0].openStatus = (int16_t)changePowerSource(allUnits[0].handle, allUnits[0].openStatus, &allUnits[0]);
			}*/
			//cout << "handle t p1->timebase_0 1: " << timebase_0 << endl;
			set_info(&allUnits[0]);
			//cout << "handle set_info p1->timebase_0 1: " << timebase_0 << endl;
			status = handleDevice(&allUnits[0]);//ͨ������ �βΣ�ͨ��ѡ���Ƿ��������̣�ƫ��
			//cout << "handle handleDevice p1->timebase_0 1: " << timebase_0 << endl;
			setResolution(&allUnits[0]);

			//cout << "handle setResolution p1->timebase_0 1: " << timebase_0 << endl;
			setTimebase(&allUnits[0]);
			displaySettings(&allUnits[0]);
		}

		if (status != PICO_OK)
		{
			printf("Picoscope devices open failed, error code 0x%x\n", (uint32_t)status);
			return 1;
		}
		return 0;
	}

}
int pico_ctrl::pico_close() {
	closeDevice(&allUnits[0]);
	return 0;
}




void pico_ctrl::setResolution(UNIT_5000* unit)
{
	int16_t value;
	int16_t i;
	int16_t numEnabledChannels = 0;
	int16_t retry;
	int32_t resolutionInput = resolution_5000;

	PICO_STATUS status;
	PS5000A_DEVICE_RESOLUTION resolution;
	PS5000A_DEVICE_RESOLUTION newResolution = PS5000A_DR_8BIT;

	// Determine number of channels enabled
	for (i = 0; i < unit->channelCount; i++)
	{
		if (unit->channelSettings[i].enabled == TRUE)
		{
			numEnabledChannels++;
		}
	}

	if (numEnabledChannels == 0)
	{
		printf("setResolution: Please enable channels.\n");
		return;
	}
	cout << "numEnabledChannels" << numEnabledChannels << endl;
	status = ps5000aGetDeviceResolution(unit->handle, &resolution);

	if (status == PICO_OK)
	{
		printf("Current resolution: ");
		printResolution(&resolution);
	}
	else
	{
		printf("setResolution_error:ps5000aGetDeviceResolution ------ 0x%08lx \n", status);
		return;
	}

	printf("\n");

	printf("Select device resolution:\n");
	printf("0: 8 bits\n");
	printf("1: 12 bits\n");
	printf("2: 14 bits\n");

	if (numEnabledChannels <= 2)
	{
		printf("3: 15 bits\n");
	}

	if (numEnabledChannels == 1)
	{
		printf("4: 16 bits\n\n");
	}

	retry = TRUE;

	do
	{
		if (numEnabledChannels == 1)
		{
			printf("Resolution [0...4]: ");
		}
		else if (numEnabledChannels == 2)
		{
			printf("Resolution [0...3]: ");
		}
		else
		{
			printf("Resolution [0...2]: ");
		}

	

		newResolution = (PS5000A_DEVICE_RESOLUTION)resolutionInput;

		// Verify if resolution can be selected for number of channels enabled

		if (newResolution == PS5000A_DR_16BIT && numEnabledChannels > 1)
		{
			printf("setResolution: 16 bit resolution can only be selected with 1 channel enabled.\n");
		}
		else if (newResolution == PS5000A_DR_15BIT && numEnabledChannels > 2)
		{
			printf("setResolution: 15 bit resolution can only be selected with a maximum of 2 channels enabled.\n");
		}
		else if (newResolution < PS5000A_DR_8BIT && newResolution > PS5000A_DR_16BIT)
		{
			printf("setResolution: Resolution index selected out of bounds.\n");
		}
		else
		{
			retry = FALSE;
		}
	} while (retry);

	printf("\n");

	status = ps5000aSetDeviceResolution(unit->handle, (PS5000A_DEVICE_RESOLUTION)newResolution);

	if (status == PICO_OK)
	{
		unit->resolution = newResolution;

		printf("Resolution selected: ");
		printResolution(&newResolution);

		// The maximum ADC value will change if transitioning from 8 bit to >= 12 bit or vice-versa
		ps5000aMaximumValue(unit->handle, &value);
		unit->maxADCValue = value;
		cout << "maxADCValue: " << unit->maxADCValue <<"\n\n" << endl;
	}
	else
	{
		printf("setResolution:ps5000aSetDeviceResolution ------ 0x%08lx \n", status);
	}

}

void pico_ctrl::setTimebase(UNIT_5000* unit)

	{
	
		PICO_STATUS status = PICO_OK;
		PICO_STATUS powerStatus = PICO_OK;
		int32_t timeInterval;
		int32_t maxSamples;
		int32_t ch;

		uint32_t shortestTimebase;
		double timeIntervalSeconds;

		PS5000A_CHANNEL_FLAGS enabledChannelOrPortFlags = (PS5000A_CHANNEL_FLAGS)0;

		int16_t numValidChannels = unit->channelCount; // Dependent on power setting - i.e. channel A & B if USB powered on 4-channel device

		if (unit->channelCount == QUAD_SCOPE)
		{
			powerStatus = ps5000aCurrentPowerSource(unit->handle);

			if (powerStatus == PICO_POWER_SUPPLY_NOT_CONNECTED)
			{
				numValidChannels = DUAL_SCOPE;
			}
		}

		// Find the analogue channels that are enabled - if an MSO model is being used, this will need to be
		// modified to add channel flags for enabled digital ports
		for (ch = 0; ch < numValidChannels; ch++)
		{
			if (unit->channelSettings[ch].enabled)
			{
				enabledChannelOrPortFlags = (PS5000A_CHANNEL_FLAGS)(1 << ch);
			}
		}

		// Find the shortest possible timebase and inform the user.
		status = ps5000aGetMinimumTimebaseStateless(unit->handle, enabledChannelOrPortFlags, &shortestTimebase, &timeIntervalSeconds, unit->resolution);
		cout << "enabledChannelOrPortFlagse: " << enabledChannelOrPortFlags << endl;
		if (status != PICO_OK)
		{
			printf("setTimebase:ps5000aGetMinimumTimebaseStateless ------ 0x%08lx \n", status);
			return;
		}

		printf("Shortest timebase index available %d (%.9f seconds).\n", shortestTimebase, timeIntervalSeconds);
		
		do
		{
			status = ps5000aGetTimebase(unit->handle, timebase_0, nSamples, &timeInterval, &maxSamples, 0);
			if (status == PICO_INVALID_NUMBER_CHANNELS_FOR_RESOLUTION)
			{
				printf("SetTimebase: Error - Invalid number of channels for resolution.\n");
				return;
			}
			else if (status == PICO_OK)
			{
				// Do nothing
			}
			else
			{
				timebase_0++; // Increase timebase if the one specified can't be used. 
			}

		} while (status != PICO_OK);
		pico_timeInterval = timeInterval;
		printf("Timebase used %lu = %ld ns sample interval\n", timebase_0, timeInterval);
	}


int pico_ctrl::set_memory() {
	int a, b;
	a = 1;
	b = 1;
	status = ps5000aMemorySegments(allUnits[0].handle, nCaptures, &maxSamples);
	cout << "maxSamples: " << maxSamples<< endl;
	if (status == PICO_OK) {
		a = 0;
	}

	status = ps5000aSetNoOfCaptures(allUnits[0].handle, nCaptures);

	if (status == PICO_OK) {
		b = 0;
	}
	if (a == 0 && b == 0) { return 0; }
	else {
		cout << "nCaptures setting is error!!!" << endl;
		return 1;
	}
}

int pico_ctrl::set_simpletrigger(PS5000A_CHANNEL ch, PS5000A_THRESHOLD_DIRECTION model, int16_t thr, int32_t delaysamples) {
	status = ps5000aSetSimpleTrigger(allUnits[0].handle, 1, ch, thr, model, delaysamples, 0);
	   /*PS5000A_CHANNEL_A,
		PS5000A_CHANNEL_B,
		PS5000A_CHANNEL_C,
		PS5000A_CHANNEL_D,
		PS5000A_EXTERNAL,*/
	if (status == PICO_OK) {
		return 0;
	}
	else return 1;
}


int pico_ctrl::set_ACORtrigger(PS5000A_THRESHOLD_DIRECTION model, int thr_a, int thr_c) {
	int cond0, cond1, cond2;
	cond0 = cond1 = cond2 = 1;
	PS5000A_CONDITION cond_1 = { PS5000A_CHANNEL_A,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION cond_2 = { PS5000A_CHANNEL_C,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION conditionsx[2] = { cond_1, cond_2 };
	PS5000A_CONDITION cond_3 = { PS5000A_CHANNEL_A,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION cond_4 = { PS5000A_CHANNEL_C,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION conditionsx2[2] = { cond_3, cond_4 };
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conditionsx, 2, PS5000A_ADD);
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conditionsx2, 2, PS5000A_ADD);
	if (status == PICO_OK) {
		cond0 = 0;
	}
	PS5000A_DIRECTION dire_1 = { PS5000A_CHANNEL_A ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire_2 = { PS5000A_CHANNEL_C ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire[2] = { dire_1,dire_2 };
	status = ps5000aSetTriggerChannelDirectionsV2(allUnits[0].handle, dire, 2);

	if (status == PICO_OK) {
		cond1 = 0;
	}
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chA_pr{ thr_a,0,0,0, PS5000A_CHANNEL_A };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chC_pr{ thr_c,0,0,0, PS5000A_CHANNEL_C };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 ch_pr[2]{ chA_pr ,chC_pr };
	status = ps5000aSetTriggerChannelPropertiesV2(allUnits[0].handle, ch_pr, 2,0);

	if (status == PICO_OK) {
		cond2 = 0;
	}
	if (cond0 == 0 && cond1 == 0 && cond2 == 0) return 0;
	else return 1;
}

int pico_ctrl::set_ABORtrigger(PS5000A_THRESHOLD_DIRECTION model, int thr_a, int thr_b) {
	int cond0, cond1, cond2;
	cond0 = cond1 = cond2 = 1;
	PS5000A_CONDITION cond_1 = { PS5000A_CHANNEL_A,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION cond_2 = { PS5000A_CHANNEL_B,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION conditionsx[2] = { cond_1, cond_2 };
	PS5000A_CONDITION cond_3 = { PS5000A_CHANNEL_A,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION cond_4 = { PS5000A_CHANNEL_B,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION conditionsx2[2] = { cond_3, cond_4 };
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conditionsx, 2, PS5000A_ADD);
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conditionsx2, 2, PS5000A_ADD);
	if (status == PICO_OK) {
		cond0 = 0;
	}
	PS5000A_DIRECTION dire_1 = { PS5000A_CHANNEL_A ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire_2 = { PS5000A_CHANNEL_B ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire[2] = { dire_1,dire_2 };
	status = ps5000aSetTriggerChannelDirectionsV2(allUnits[0].handle, dire, 2);

	if (status == PICO_OK) {
		cond1 = 0;
	}
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chA_pr{ thr_a,0,0,0, PS5000A_CHANNEL_A };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chC_pr{ thr_b,0,0,0, PS5000A_CHANNEL_B };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 ch_pr[2]{ chA_pr ,chC_pr };
	status = ps5000aSetTriggerChannelPropertiesV2(allUnits[0].handle, ch_pr, 2, 0);

	if (status == PICO_OK) {
		cond2 = 0;
	}
	if (cond0 == 0 && cond1 == 0 && cond2 == 0) return 0;
	else return 1;
}
int pico_ctrl::set_BCORtrigger(PS5000A_THRESHOLD_DIRECTION model, int thr_b, int thr_c) {
	int cond0, cond1, cond2;
	cond0 = cond1 = cond2 = 1;
	PS5000A_CONDITION cond_1 = { PS5000A_CHANNEL_B,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION cond_2 = { PS5000A_CHANNEL_C,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION conditionsx[2] = { cond_1, cond_2 };
	PS5000A_CONDITION cond_3 = { PS5000A_CHANNEL_B,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION cond_4 = { PS5000A_CHANNEL_C,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION conditionsx2[2] = { cond_3, cond_4 };
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conditionsx, 2, PS5000A_ADD);
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conditionsx2, 2, PS5000A_ADD);
	if (status == PICO_OK) {
		cond0 = 0;
	}
	PS5000A_DIRECTION dire_1 = { PS5000A_CHANNEL_B ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire_2 = { PS5000A_CHANNEL_C ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire[2] = { dire_1,dire_2 };
	status = ps5000aSetTriggerChannelDirectionsV2(allUnits[0].handle, dire, 2);

	if (status == PICO_OK) {
		cond1 = 0;
	}
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chB_pr{ thr_b,0,0,0, PS5000A_CHANNEL_B };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chC_pr{ thr_c,0,0,0, PS5000A_CHANNEL_C };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 ch_pr[2]{ chB_pr ,chC_pr };
	status = ps5000aSetTriggerChannelPropertiesV2(allUnits[0].handle, ch_pr, 2, 0);

	if (status == PICO_OK) {
		cond2 = 0;
	}
	if (cond0 == 0 && cond1 == 0 && cond2 == 0) return 0;
	else return 1;
}
int pico_ctrl::set_ABCORtrigger(PS5000A_THRESHOLD_DIRECTION model, int thr_a, int thr_b, int thr_c) {
	int cond0, cond1, cond2;
	cond0 = cond1 = cond2 = 1;

	PS5000A_CONDITION cond10 = { PS5000A_CHANNEL_A,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION cond11 = { PS5000A_CHANNEL_A,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION cond20 = { PS5000A_CHANNEL_B,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION cond21 = { PS5000A_CHANNEL_B,PS5000A_CONDITION_DONT_CARE };
	PS5000A_CONDITION cond30 = { PS5000A_CHANNEL_C,PS5000A_CONDITION_TRUE };
	PS5000A_CONDITION cond31 = { PS5000A_CHANNEL_C,PS5000A_CONDITION_DONT_CARE };

	PS5000A_CONDITION conds1[3] = { cond10,cond21,cond31 };
	PS5000A_CONDITION conds2[3] = { cond11,cond20,cond31 };
	PS5000A_CONDITION conds3[3] = { cond11,cond21,cond30 };
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conds1, 3, PS5000A_ADD);
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conds2, 3, PS5000A_ADD);
	status = ps5000aSetTriggerChannelConditionsV2(allUnits[0].handle, conds3, 3, PS5000A_ADD);

	if (status == PICO_OK) {
		cond0 = 0;
	}
	PS5000A_DIRECTION dire_1 = { PS5000A_CHANNEL_A ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire_2 = { PS5000A_CHANNEL_B ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dire_3 = { PS5000A_CHANNEL_C ,model,PS5000A_LEVEL };
	PS5000A_DIRECTION dires[3] = { dire_1, dire_2, dire_3 };
	status = ps5000aSetTriggerChannelDirectionsV2(allUnits[0].handle, dires, 3);

	if (status == PICO_OK) {
		cond1 = 0;
	}
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chA_pr{ thr_a,0,0,0, PS5000A_CHANNEL_A };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chB_pr{ thr_b,0,0,0, PS5000A_CHANNEL_B };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 chC_pr{ thr_c,0,0,0, PS5000A_CHANNEL_C };
	PS5000A_TRIGGER_CHANNEL_PROPERTIES_V2 ch_pr[3]{ chA_pr ,chB_pr ,chC_pr };
	status = ps5000aSetTriggerChannelPropertiesV2(allUnits[0].handle, ch_pr, 3, 0);

	if (status == PICO_OK) {
		cond2 = 0;
	}
	if (cond0 == 0 && cond1 == 0 && cond2 == 0) return 0;
	else return 1;
}
//
int pico_ctrl::get_rapidBuffer(PS5000A_CHANNEL ch,int16_t** rapidBuffer_channel0) {
//	//if (status == PICO_OK) cout << "yes" << endl;
//	PICO_ACTION add = PICO_ADD, clear = PICO_CLEAR_ALL;
//	PICO_ACTION action;
//	action = PICO_ACTION(PICO_ADD | PICO_CLEAR_ALL);
	clock_t t1, t2, t3, t4, t5, t6;
	t1 = clock();
	int16_t ready_0;
	int16_t* overflow;
	int capture;
	overflow = (int16_t*)calloc(nCaptures, sizeof(int16_t));
	
	for (capture = 0; capture < nCaptures; capture++)
	{
		status = ps5000aSetDataBuffer(allUnits[0].handle, ch, rapidBuffer_channel0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
	}
	t2 = clock();
	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, NULL, 0, NULL, NULL);

	ps5000aIsReady(allUnits[0].handle, &ready_0);
	while (ready_0 == 0) {
		ps5000aIsReady(allUnits[0].handle, &ready_0);
	}
	t3 = clock();
	status = ps5000aGetValuesBulk(allUnits[0].handle, &nSamples, 0, nCaptures - 1, 1, PS5000A_RATIO_MODE_NONE, overflow);
	free(overflow);
	t4 = clock();
	//cout <<"1: " << (double(t2 - t1) / CLOCKS_PER_SEC) << " 2: " << (double(t3 - t2) / CLOCKS_PER_SEC) << "3:  " << (double(t4 - t3) / CLOCKS_PER_SEC)<< " 4:  " << (double(t4 - t1) / CLOCKS_PER_SEC) << endl;
	return 0;
}


int pico_ctrl::get_rapidBuffers(int16_t** rapidBuffers_A0, int16_t** rapidBuffers_C0) {
	clock_t t1, t2, t3, t4, t5, t6;
	t1 = t2 = t3 = t4 = t5 = t6 = 0;
	//if (status == PICO_OK) cout << "yes" << endl;
	//t1 = clock();
	int16_t ready_0; 
	int32_t		timeIndisposed;
	int16_t* overflow;
	int capture;
	int16_t		retry;
	t1 = clock();
	//PICO_ACTION add = PICO_ADD, clear = PICO_CLEAR_ALL;
	//PICO_ACTION action;
	//action = PICO_ACTION(PICO_ADD | PICO_CLEAR_ALL);
	overflow = (int16_t*)calloc(2 * nCaptures, sizeof(int16_t));
	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, NULL, 0, NULL, NULL);
	//do
	//{
	//	retry = 0;
	//	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, &timeIndisposed, 0, callBackBlock, NULL);

	//	if (status != PICO_OK)
	//	{
	//		// PicoScope 5X4XA/B/D devices...+5 V PSU connected or removed or
	//		// PicoScope 524XD devices on non-USB 3.0 port
	//			printf("collectRapidBlock:ps5000aRunBlock ------ 0x%08lx \n", status);
	//	}
	//} while (retry);
	//// Wait until data ready
	//g_ready = 0;

	//while (!g_ready && !_kbhit())
	//{
	//	Sleep(0);
	//}


	//t2 = clock();
	ps5000aIsReady(allUnits[0].handle, &ready_0);
	while (ready_0 == 0) {
		ps5000aIsReady(allUnits[0].handle, &ready_0);
	}
	//t3 = clock();
	for (capture = 0; capture < nCaptures; capture++)
	{
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_B, rapidBuffers_A0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_C, rapidBuffers_C0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
	}
	
	
	status = ps5000aGetValuesBulk(allUnits[0].handle, &nSamples, 0, nCaptures - 1, 1, PS5000A_RATIO_MODE_NONE, overflow);

	free(overflow);
	//t4 = clock();
	//cout << "buffer1:  " << (double(t2 - t1) / CLOCKS_PER_SEC) << " buffer2:  " << (double(t3 - t2) / CLOCKS_PER_SEC)<< "  buffer3: " << (double(t4 - t3) / CLOCKS_PER_SEC)<< "  buffer4: " << (double(t4 - t1) / CLOCKS_PER_SEC) << endl;
	return 0;

}
int pico_ctrl::get_rapidBuffer_AD(int16_t** rapidBuffers_A0, int16_t** rapidBuffers_D0) {
	int16_t ready_0;
	int32_t		timeIndisposed;
	int16_t* overflow;
	int capture;
	int16_t		retry;
	overflow = (int16_t*)calloc(2 * nCaptures, sizeof(int16_t));
	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, NULL, 0, NULL, NULL);
	ps5000aIsReady(allUnits[0].handle, &ready_0);
	while (ready_0 == 0) {
		ps5000aIsReady(allUnits[0].handle, &ready_0);
	}

	for (capture = 0; capture < nCaptures; capture++)
	{
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_A, rapidBuffers_A0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_C, rapidBuffers_D0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
	}

	status = ps5000aGetValuesBulk(allUnits[0].handle, &nSamples, 0, nCaptures - 1, 1, PS5000A_RATIO_MODE_NONE, overflow);

	free(overflow);
	return 0;

}
int pico_ctrl::get_rapidBuffers_ACD(int16_t** rapidBuffers_A0, int16_t** rapidBuffers_C0 ,int16_t** rapidBuffers_D0) {
	//clock_t t1, t2, t3, t4, t5, t6;
	//t1 = t2 = t3 = t4 = t5 = t6 = 0;
	//if (status == PICO_OK) cout << "yes" << endl;
	//t1 = clock();
	int16_t ready_0;
	int32_t		timeIndisposed;
	int16_t* overflow;
	int capture;
	int16_t		retry;

	overflow = (int16_t*)calloc(2 * nCaptures, sizeof(int16_t));
	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, NULL, 0, NULL, NULL);

	//t2 = clock();
	ps5000aIsReady(allUnits[0].handle, &ready_0);
	while (ready_0 == 0) {
		ps5000aIsReady(allUnits[0].handle, &ready_0);
	}
	//t3 = clock();
	for (capture = 0; capture < nCaptures; capture++)
	{
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_A, rapidBuffers_A0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_B, rapidBuffers_C0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_D, rapidBuffers_D0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);

	}

	//t4 = clock();
	status = ps5000aGetValuesBulk(allUnits[0].handle, &nSamples, 0, nCaptures - 1, 1, PS5000A_RATIO_MODE_NONE, overflow);

	free(overflow);


	//cout << "buffer1: " << (double(t2 - t1) / CLOCKS_PER_SEC) << "    buffer2: " << (double(t3 - t2) / CLOCKS_PER_SEC) << "    buffer3: " << (double(t4 - t3) / CLOCKS_PER_SEC) << endl;
	return 0;

}

int pico_ctrl::get_rapidBuffers_ABC(int16_t** rapidBuffers_A0, int16_t** rapidBuffers_B0, int16_t** rapidBuffers_C0) {
	//clock_t t1, t2, t3, t4, t5, t6;
	//t1 = t2 = t3 = t4 = t5 = t6 = 0;
	//if (status == PICO_OK) cout << "yes" << endl;
	//t1 = clock();
	int16_t ready_0;
	int32_t		timeIndisposed;
	int16_t* overflow;
	int capture;
	int16_t		retry;

	overflow = (int16_t*)calloc(2 * nCaptures, sizeof(int16_t));
	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, NULL, 0, NULL, NULL);

	//t2 = clock();
	ps5000aIsReady(allUnits[0].handle, &ready_0);
	while (ready_0 == 0) {
		ps5000aIsReady(allUnits[0].handle, &ready_0);
	}
	//t3 = clock();
	for (capture = 0; capture < nCaptures; capture++)
	{
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_A, rapidBuffers_A0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_B, rapidBuffers_B0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_C, rapidBuffers_C0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);

	}

	
	status = ps5000aGetValuesBulk(allUnits[0].handle, &nSamples, 0, nCaptures - 1, 1, PS5000A_RATIO_MODE_NONE, overflow);

	free(overflow);
	//t4 = clock();

	//cout << "buffer1: " << (double(t2 - t1) / CLOCKS_PER_SEC) << "    buffer2: " << (double(t3 - t2) / CLOCKS_PER_SEC) << "    buffer3: " << (double(t4 - t3) / CLOCKS_PER_SEC) << "    buffer4: " << (double(t4 - t1) / CLOCKS_PER_SEC) << endl;
	return 0;

}
int pico_ctrl::get_rapidBuffers_ABCD(int16_t** rapidBuffers_A0, int16_t** rapidBuffers_B0, int16_t** rapidBuffers_C0, int16_t** rapidBuffers_D0) {
	clock_t t1, t2, t3, t4, t5, t6;
	t1 = t2 = t3 = t4 = t5 = t6 = 0;
	//if (status == PICO_OK) cout << "yes" << endl;
	t1 = clock();
	int16_t ready_0;
	int32_t		timeIndisposed;
	int16_t* overflow;
	int capture;
	int16_t		retry;

	overflow = (int16_t*)calloc(2 * nCaptures, sizeof(int16_t));
	status = ps5000aRunBlock(allUnits[0].handle, npreSamples, npostSamples, timebase_0, NULL, 0, NULL, NULL);

	t2 = clock();
	ps5000aIsReady(allUnits[0].handle, &ready_0);
	while (ready_0 == 0) {
		ps5000aIsReady(allUnits[0].handle, &ready_0);
	}
	t3 = clock();
	for (capture = 0; capture < nCaptures; capture++)
	{
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_A, rapidBuffers_A0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_B, rapidBuffers_B0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_C, rapidBuffers_C0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);
		status = ps5000aSetDataBuffer(allUnits[0].handle, PS5000A_CHANNEL_D, rapidBuffers_D0[capture], nSamples, capture, PS5000A_RATIO_MODE_NONE);

	}

	
	status = ps5000aGetValuesBulk(allUnits[0].handle, &nSamples, 0, nCaptures - 1, 1, PS5000A_RATIO_MODE_NONE, overflow);

	free(overflow);
	t4 = clock();

	cout << "buffer1: " << (double(t2 - t1) / CLOCKS_PER_SEC) << "    buffer2: " << (double(t3 - t2) / CLOCKS_PER_SEC) << "    buffer3: " << (double(t4 - t3) / CLOCKS_PER_SEC)  <<"   buffer4: " << (double(t4 - t1) / CLOCKS_PER_SEC) << endl;
	return 0;

}
void pico_ctrl::TEST() {
	cout << "here TEST channelCount:" << allUnits[0].channelCount << endl;
}